const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read medicines or users", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("medicines").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
});

test("Authenticated user: cannot read another user's profile or medicine", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("users").doc(BOB_UID).set({
      userId: BOB_UID,
      name: "Bob Sharma",
      age: 68,
      bloodGroup: "B+",
      allergies: "None",
      language: "Hindi",
      accountMode: "patient",
      inviteCode: "MM-1234",
      phone: "+919876543210",
      createdAt: now,
      updatedAt: now,
    });
    await context.firestore().collection("medicines").doc("bob_med_1").set({
      userId: BOB_UID,
      memberId: "member_bob",
      patientName: "Bob Sharma",
      name: "Metformin 500mg",
      dosage: "1 tablet",
      timeSlot: "Morning",
      scheduledTime: "08:00 AM",
      mealInstruction: "After Breakfast",
      conditionTag: "Diabetes",
      bioscienceMechanism: "AMPK activator",
      stockRemaining: 30,
      takenToday: false,
      todayStatus: "pending",
      createdAt: now,
      updatedAt: now,
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("users").doc(BOB_UID).get());
  await assertFails(aliceDb.collection("medicines").doc("bob_med_1").get());
});

test("Authenticated user: can create and query own medicines with userId filter", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 1000);
  await assertSucceeds(
    aliceDb.collection("medicines").doc("med_1").set({
      userId: ALICE_UID,
      memberId: "member_1",
      patientName: "Kamla ji",
      name: "Metformin 500mg",
      dosage: "1 tablet",
      timeSlot: "Morning",
      scheduledTime: "08:00 AM",
      mealInstruction: "Before Breakfast",
      conditionTag: "Diabetes",
      bioscienceMechanism: "AMPK activation reduces hepatic glucose output.",
      stockRemaining: 28,
      takenToday: false,
      todayStatus: "pending",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("medicines").where("userId", "==", ALICE_UID).get()
  );
});

test("Authenticated user: fails shadow update with ghost field", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 1000);
  await assertFails(
    aliceDb.collection("medicines").doc("med_ghost").set({
      userId: ALICE_UID,
      memberId: "member_1",
      patientName: "Kamla ji",
      name: "Metformin 500mg",
      dosage: "1 tablet",
      timeSlot: "Morning",
      scheduledTime: "08:00 AM",
      mealInstruction: "Before Breakfast",
      conditionTag: "Diabetes",
      bioscienceMechanism: "AMPK activation",
      stockRemaining: 28,
      takenToday: false,
      todayStatus: "pending",
      isVerifiedGhost: true,
      createdAt: now,
      updatedAt: now,
    })
  );
});
