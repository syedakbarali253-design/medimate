package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class MedMateRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createMedicine_validPayload_createsDocumentAndReturnsId() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repository = MedMateRepository(firestore)

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createMedicine(
                memberId = "fam_kamla",
                patientName = "Kamla ji",
                name = "Metformin 500mg",
                dosage = "1 tablet",
                timeSlot = "Morning",
                scheduledTime = "08:00 AM",
                mealInstruction = "Before Breakfast",
                conditionTag = "Diabetes",
                bioscienceMechanism = "AMPK activator"
            )
        }
        assertTrue(createResult.isSuccess)
        val medId = createResult.getOrThrow()
        assertTrue(medId.isNotEmpty())
    }

    @Test
    fun observeMedicines_authenticatedOwner_emitsRealtimeUpdates() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repository = MedMateRepository(firestore)
        val medId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createMedicine(
                memberId = "fam_kamla",
                patientName = "Kamla ji",
                name = "Thyroxine 50mcg",
                dosage = "1 tablet",
                timeSlot = "Afternoon",
                scheduledTime = "01:00 PM",
                mealInstruction = "After Lunch",
                conditionTag = "Thyroid",
                bioscienceMechanism = "Synthetic T4 prohormone"
            ).getOrThrow()
        }

        val emittedMeds = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeMedicines().first { list -> list.any { it.id == medId } }
        }
        assertTrue(emittedMeds.map { it.id }.contains(medId))
    }

    @Test
    fun getMedicineById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val aliceRepo = MedMateRepository(firestore)
        val medId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createMedicine(
                memberId = "fam_kamla",
                patientName = "Kamla ji",
                name = "Atorvastatin 10mg",
                dosage = "1 tablet",
                timeSlot = "Night",
                scheduledTime = "09:00 PM",
                mealInstruction = "After Dinner",
                conditionTag = "Cholesterol",
                bioscienceMechanism = "HMG-CoA reductase inhibitor"
            ).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = MedMateRepository(firestore)
        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.getMedicineById(medId)
        }
        assertTrue(result.isFailure)
        val firestoreException = result.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull(firestoreException)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
    }

    @Test
    fun observeMedicines_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = MedMateRepository(firestore)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeMedicines("unauth_uid").first()
            }
            fail("Expected exception for unauthenticated user")
        } catch (e: Exception) {
            val firestoreException = e.unwrapFirestoreException()
            assertNotNull("Expected FirebaseFirestoreException, got $e", firestoreException)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice_medmate@test.com"
        const val BOB_EMAIL = "bob_medmate@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
