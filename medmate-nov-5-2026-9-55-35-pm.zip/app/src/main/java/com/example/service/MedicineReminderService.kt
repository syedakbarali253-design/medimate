package com.example.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import com.example.MainActivity
import com.example.data.model.Medicine
import com.example.util.ReminderNotificationHelper
import java.util.Calendar
import java.util.Locale

/**
 * Android Service that handles local scheduled notifications, audible alarm chimes,
 * and spoken TextToSpeech voice reminders (English, Hindi, Telugu) when triggered by AlarmManager.
 */
class MedicineReminderService : Service() {

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: MedicineAlarmScheduler.ACTION_TRIGGER_DOSE_REMINDER
        val medicineName = intent?.getStringExtra(MedicineAlarmScheduler.EXTRA_MEDICINE_NAME) ?: "Metformin 500 mg"
        val dosage = intent?.getStringExtra(MedicineAlarmScheduler.EXTRA_DOSAGE) ?: "1 tablet"
        val scheduledTime = intent?.getStringExtra(MedicineAlarmScheduler.EXTRA_SCHEDULED_TIME) ?: "1:00 PM"
        val instructions = intent?.getStringExtra(MedicineAlarmScheduler.EXTRA_INSTRUCTIONS) ?: "After Meals"
        val patientName = intent?.getStringExtra(MedicineAlarmScheduler.EXTRA_PATIENT_NAME) ?: "Mr. Rao"
        val language = intent?.getStringExtra(MedicineAlarmScheduler.EXTRA_LANGUAGE) ?: "English"
        val voiceEnabled = intent?.getBooleanExtra(MedicineAlarmScheduler.EXTRA_VOICE_ENABLED, true) ?: true

        dispatchReminderAndVoice(
            context = applicationContext,
            action = action,
            medicineName = medicineName,
            dosage = dosage,
            scheduledTime = scheduledTime,
            instructions = instructions,
            patientName = patientName,
            language = language,
            voiceEnabled = voiceEnabled
        )

        // Allow TTS to initialize and speak before stopping the service
        mainHandler.postDelayed({
            stopSelfResult(startId)
        }, 4500L)

        return START_NOT_STICKY
    }

    companion object {
        private const val TAG = "MedicineReminderSvc"

        fun dispatchReminderAndVoice(
            context: Context,
            action: String,
            medicineName: String,
            dosage: String,
            scheduledTime: String,
            instructions: String,
            patientName: String,
            language: String,
            voiceEnabled: Boolean
        ) {
            val isCaregiverEscalation = action == MedicineAlarmScheduler.ACTION_CHECK_UNCONFIRMED_DOSE

            if (isCaregiverEscalation) {
                MediMateFcmManager.sendCaregiverMissedDoseAlertPush(
                    context = context,
                    patientName = patientName,
                    medicineName = medicineName,
                    dosage = dosage,
                    scheduledTime = scheduledTime,
                    language = if (voiceEnabled) language else "English"
                )
            } else {
                MediMateFcmManager.sendPatientMedicineReminderPush(
                    context = context,
                    patientName = patientName,
                    medicineName = medicineName,
                    dosage = dosage,
                    scheduledTime = scheduledTime,
                    instructions = instructions,
                    language = if (voiceEnabled) language else "English"
                )
            }
            Log.d(TAG, "Dispatched FCM + local $action for $medicineName ($patientName) in $language")
        }
    }
}

/**
 * BroadcastReceiver invoked by AlarmManager at scheduled medicine times or after the
 * caregiver grace window. Starts MedicineReminderService (with direct fallback on Android 12+ background).
 */
class MedicineReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED) {
            ReminderNotificationHelper.ensureChannel(context)
            return
        }

        val medicineName = intent.getStringExtra(MedicineAlarmScheduler.EXTRA_MEDICINE_NAME) ?: "Metformin 500 mg"
        val dosage = intent.getStringExtra(MedicineAlarmScheduler.EXTRA_DOSAGE) ?: "1 tablet"
        val scheduledTime = intent.getStringExtra(MedicineAlarmScheduler.EXTRA_SCHEDULED_TIME) ?: "1:00 PM"
        val instructions = intent.getStringExtra(MedicineAlarmScheduler.EXTRA_INSTRUCTIONS) ?: "After Meals"
        val patientName = intent.getStringExtra(MedicineAlarmScheduler.EXTRA_PATIENT_NAME) ?: "Mr. Rao"
        val language = intent.getStringExtra(MedicineAlarmScheduler.EXTRA_LANGUAGE) ?: "English"
        val voiceEnabled = intent.getBooleanExtra(MedicineAlarmScheduler.EXTRA_VOICE_ENABLED, true)

        try {
            val serviceIntent = Intent(context, MedicineReminderService::class.java).apply {
                this.action = action
                putExtra(MedicineAlarmScheduler.EXTRA_MEDICINE_NAME, medicineName)
                putExtra(MedicineAlarmScheduler.EXTRA_DOSAGE, dosage)
                putExtra(MedicineAlarmScheduler.EXTRA_SCHEDULED_TIME, scheduledTime)
                putExtra(MedicineAlarmScheduler.EXTRA_INSTRUCTIONS, instructions)
                putExtra(MedicineAlarmScheduler.EXTRA_PATIENT_NAME, patientName)
                putExtra(MedicineAlarmScheduler.EXTRA_LANGUAGE, language)
                putExtra(MedicineAlarmScheduler.EXTRA_VOICE_ENABLED, voiceEnabled)
            }
            context.startService(serviceIntent)
        } catch (_: Exception) {
            // Fallback if background service start is restricted by OS power management
            MedicineReminderService.dispatchReminderAndVoice(
                context = context,
                action = action,
                medicineName = medicineName,
                dosage = dosage,
                scheduledTime = scheduledTime,
                instructions = instructions,
                patientName = patientName,
                language = language,
                voiceEnabled = voiceEnabled
            )
        }
    }
}

/**
 * AlarmManager coordinator that schedules local medicine reminders, snooze timers,
 * and automatic caregiver missed-dose escalation checks.
 */
object MedicineAlarmScheduler {
    const val ACTION_TRIGGER_DOSE_REMINDER = "com.example.action.TRIGGER_DOSE_REMINDER"
    const val ACTION_CHECK_UNCONFIRMED_DOSE = "com.example.action.CHECK_UNCONFIRMED_DOSE"

    const val EXTRA_MEDICINE_ID = "extra_medicine_id"
    const val EXTRA_MEDICINE_NAME = "extra_medicine_name"
    const val EXTRA_DOSAGE = "extra_dosage"
    const val EXTRA_SCHEDULED_TIME = "extra_scheduled_time"
    const val EXTRA_INSTRUCTIONS = "extra_instructions"
    const val EXTRA_PATIENT_NAME = "extra_patient_name"
    const val EXTRA_LANGUAGE = "extra_language"
    const val EXTRA_VOICE_ENABLED = "extra_voice_enabled"

    /**
     * Schedules both the primary dose reminder and the caregiver grace-period check
     * for every unconfirmed medicine in the patient's daily schedule.
     */
    fun scheduleAllDailyMedicineAlarms(
        context: Context,
        medicines: List<Medicine>,
        language: String = "English",
        gracePeriodMinutes: Int = 30,
        voiceEnabled: Boolean = true
    ): Int {
        var scheduledCount = 0
        medicines.forEach { med ->
            if (!med.takenToday && med.todayStatus != "taken") {
                val ok = scheduleMedicineReminder(
                    context = context,
                    medicine = med,
                    language = language,
                    gracePeriodMinutes = gracePeriodMinutes,
                    voiceEnabled = voiceEnabled
                )
                if (ok) scheduledCount += 1
            } else {
                // If already taken today, cancel any pending caregiver escalation alarm
                cancelMedicineAlarms(context, med.id.ifBlank { med.name })
            }
        }
        return scheduledCount
    }

    /**
     * Schedules a single medicine's primary reminder alarm + caregiver grace-period escalation alarm.
     */
    fun scheduleMedicineReminder(
        context: Context,
        medicine: Medicine,
        language: String = "English",
        gracePeriodMinutes: Int = 30,
        voiceEnabled: Boolean = true
    ): Boolean {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
        val key = medicine.id.ifBlank { medicine.name }
        val doseTriggerAtMillis = parseScheduledTimeToMillis(medicine.scheduledTime)
        val caregiverEscalationAtMillis = doseTriggerAtMillis + (gracePeriodMinutes * 60_000L)

        val dosePendingIntent = buildReminderPendingIntent(
            context = context,
            requestCode = key.hashCode(),
            action = ACTION_TRIGGER_DOSE_REMINDER,
            medicineId = key,
            medicineName = medicine.name,
            dosage = medicine.dosage,
            scheduledTime = medicine.scheduledTime,
            instructions = medicine.mealInstruction,
            patientName = medicine.patientName.ifBlank { "Mr. Rao" },
            language = language,
            voiceEnabled = voiceEnabled
        )

        val caregiverPendingIntent = buildReminderPendingIntent(
            context = context,
            requestCode = (key + "_escalation").hashCode(),
            action = ACTION_CHECK_UNCONFIRMED_DOSE,
            medicineId = key,
            medicineName = medicine.name,
            dosage = medicine.dosage,
            scheduledTime = medicine.scheduledTime,
            instructions = medicine.mealInstruction,
            patientName = medicine.patientName.ifBlank { "Mr. Rao" },
            language = language,
            voiceEnabled = voiceEnabled
        )

        return try {
            setAlarmSafely(alarmManager, doseTriggerAtMillis, dosePendingIntent)
            setAlarmSafely(alarmManager, caregiverEscalationAtMillis, caregiverPendingIntent)
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Schedules an AlarmManager broadcast after [delaySeconds] (e.g., 15-min snooze or 2-sec live alarm test)
     * and also starts MedicineReminderService when [triggerImmediately] is true.
     */
    fun scheduleDelayReminder(
        context: Context,
        medicineName: String,
        dosage: String = "1 tablet",
        scheduledTime: String = "1:00 PM",
        instructions: String = "After Meals",
        patientName: String = "Mr. Rao",
        language: String = "English",
        delaySeconds: Int = 3,
        isCaregiverEscalation: Boolean = false,
        voiceEnabled: Boolean = true,
        triggerImmediately: Boolean = false
    ): Boolean {
        val action = if (isCaregiverEscalation) ACTION_CHECK_UNCONFIRMED_DOSE else ACTION_TRIGGER_DOSE_REMINDER

        if (triggerImmediately) {
            try {
                val serviceIntent = Intent(context, MedicineReminderService::class.java).apply {
                    this.action = action
                    putExtra(EXTRA_MEDICINE_NAME, medicineName)
                    putExtra(EXTRA_DOSAGE, dosage)
                    putExtra(EXTRA_SCHEDULED_TIME, scheduledTime)
                    putExtra(EXTRA_INSTRUCTIONS, instructions)
                    putExtra(EXTRA_PATIENT_NAME, patientName)
                    putExtra(EXTRA_LANGUAGE, language)
                    putExtra(EXTRA_VOICE_ENABLED, voiceEnabled)
                }
                context.startService(serviceIntent)
            } catch (_: Exception) {
                MedicineReminderService.dispatchReminderAndVoice(
                    context = context,
                    action = action,
                    medicineName = medicineName,
                    dosage = dosage,
                    scheduledTime = scheduledTime,
                    instructions = instructions,
                    patientName = patientName,
                    language = language,
                    voiceEnabled = voiceEnabled
                )
            }
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
        val triggerAtMillis = System.currentTimeMillis() + (delaySeconds.coerceAtLeast(1) * 1000L)
        val pendingIntent = buildReminderPendingIntent(
            context = context,
            requestCode = (medicineName + action + delaySeconds).hashCode(),
            action = action,
            medicineId = medicineName,
            medicineName = medicineName,
            dosage = dosage,
            scheduledTime = scheduledTime,
            instructions = instructions,
            patientName = patientName,
            language = language,
            voiceEnabled = voiceEnabled
        )

        return try {
            setAlarmSafely(alarmManager, triggerAtMillis, pendingIntent)
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Cancels both the scheduled dose reminder and the caregiver unconfirmed-dose check
     * once a patient confirms taking their medicine.
     */
    fun cancelMedicineAlarms(context: Context, medicineIdOrName: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

        val doseIntent = Intent(context, MedicineReminderReceiver::class.java).apply {
            action = ACTION_TRIGGER_DOSE_REMINDER
        }
        val dosePi = PendingIntent.getBroadcast(
            context,
            medicineIdOrName.hashCode(),
            doseIntent,
            flags
        )
        alarmManager.cancel(dosePi)

        val escalationIntent = Intent(context, MedicineReminderReceiver::class.java).apply {
            action = ACTION_CHECK_UNCONFIRMED_DOSE
        }
        val escalationPi = PendingIntent.getBroadcast(
            context,
            (medicineIdOrName + "_escalation").hashCode(),
            escalationIntent,
            flags
        )
        alarmManager.cancel(escalationPi)
    }

    /**
     * Parses clock strings like "8:00 AM", "1:00 PM", "8:00 PM", or "08:30 AM" into the next
     * future epoch timestamp in milliseconds.
     */
    internal fun parseScheduledTimeToMillis(scheduledTime: String): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val cleaned = scheduledTime.trim().uppercase(Locale.ENGLISH)
        val isPm = cleaned.contains("PM")
        val isAm = cleaned.contains("AM")
        val timePart = cleaned
            .replace("AM", "")
            .replace("PM", "")
            .substringBefore("&")
            .trim()

        val parts = timePart.split(":")
        val parsedHour = parts.getOrNull(0)?.trim()?.toIntOrNull() ?: 8
        val parsedMinute = parts.getOrNull(1)?.trim()?.take(2)?.toIntOrNull() ?: 0

        val hour24 = when {
            isPm && parsedHour in 1..11 -> parsedHour + 12
            isAm && parsedHour == 12 -> 0
            else -> parsedHour.coerceIn(0, 23)
        }

        target.set(Calendar.HOUR_OF_DAY, hour24)
        target.set(Calendar.MINUTE, parsedMinute.coerceIn(0, 59))

        if (target.timeInMillis <= now.timeInMillis) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }
        return target.timeInMillis
    }

    private fun setAlarmSafely(
        alarmManager: AlarmManager,
        triggerAtMillis: Long,
        operation: PendingIntent
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    operation
                )
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    operation
                )
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                operation
            )
        } else {
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                operation
            )
        }
    }

    private fun buildReminderPendingIntent(
        context: Context,
        requestCode: Int,
        action: String,
        medicineId: String,
        medicineName: String,
        dosage: String,
        scheduledTime: String,
        instructions: String,
        patientName: String,
        language: String,
        voiceEnabled: Boolean
    ): PendingIntent {
        val intent = Intent(context, MedicineReminderReceiver::class.java).apply {
            this.action = action
            putExtra(EXTRA_MEDICINE_ID, medicineId)
            putExtra(EXTRA_MEDICINE_NAME, medicineName)
            putExtra(EXTRA_DOSAGE, dosage)
            putExtra(EXTRA_SCHEDULED_TIME, scheduledTime)
            putExtra(EXTRA_INSTRUCTIONS, instructions)
            putExtra(EXTRA_PATIENT_NAME, patientName)
            putExtra(EXTRA_LANGUAGE, language)
            putExtra(EXTRA_VOICE_ENABLED, voiceEnabled)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, requestCode, intent, flags)
    }
}
