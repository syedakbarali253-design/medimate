package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.animateLottieCompositionAsState
import com.airbnb.lottie.compose.rememberLottieComposition
import com.example.R
import com.example.data.model.FamilyMember
import com.example.data.model.Medicine
import com.example.ui.theme.MedAlertRed
import com.example.ui.theme.MedAmberWarning
import com.example.ui.theme.MedNavyBlue
import com.example.ui.theme.MedTakenGreen
import com.example.ui.theme.MedTealContainer
import com.example.ui.theme.MedTealDark
import com.example.service.MedicineAlarmScheduler
import com.example.ui.theme.MedTealPrimary
import com.example.util.ReminderNotificationHelper
import com.example.viewmodel.AiTaskState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

/**
 * Screen 1 (Elderly Patient Dashboard) & Screen 2 (My Medicines) from
 * MediMate_Elder_Care_App_Dashboard__1__ccc801df.png
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PatientTodayScreen(
    familyMembers: List<FamilyMember>,
    selectedMemberId: String?,
    onSelectMember: (String) -> Unit,
    medicines: List<Medicine>,
    selectedLanguage: String = "English",
    onLanguageChange: (String) -> Unit = {},
    isDemoMode: Boolean = false,
    quickGuideState: AiTaskState<String>,
    onRequestQuickGuide: (Medicine) -> Unit,
    onDismissQuickGuide: () -> Unit,
    onMarkDoseStatus: (Medicine, String, String) -> Unit,
    onAddMedicine: (String, String, String, String, String, String, String, String, String) -> Unit,
    onSimulateMissedDoseAlert: (Medicine) -> Unit = {}
) {
    val context = LocalContext.current
    val activeMember = familyMembers.find { it.id == selectedMemberId } ?: familyMembers.firstOrNull()
    val patientMedicines = remember(medicines, activeMember) {
        if (activeMember != null) {
            val filtered = medicines.filter { it.memberId == activeMember.id || it.patientName == activeMember.name }
            if (filtered.isNotEmpty()) filtered else medicines
        } else {
            medicines
        }
    }

    var focusedMedicine by remember { mutableStateOf<Medicine?>(null) }
    var showAddMedicineDialog by remember { mutableStateOf(false) }
    var lastConfirmedMedicineName by remember { mutableStateOf<String?>(null) }
    var confirmationPulseId by remember { mutableIntStateOf(0) }

    // Automatically register scheduled AlarmManager reminders & caregiver grace-period checks
    LaunchedEffect(patientMedicines, selectedLanguage) {
        MedicineAlarmScheduler.scheduleAllDailyMedicineAlarms(
            context = context,
            medicines = patientMedicines,
            language = selectedLanguage,
            gracePeriodMinutes = 30,
            voiceEnabled = true
        )
    }

    LaunchedEffect(confirmationPulseId) {
        if (confirmationPulseId > 0) {
            delay(4800L)
            lastConfirmedMedicineName = null
        }
    }

    if (focusedMedicine != null) {
        BackHandler { focusedMedicine = null }
        FocusedElderlyDoseScreen(
            medicine = focusedMedicine!!,
            allDayMedicines = patientMedicines,
            onMarkTaken = {
                if (!focusedMedicine!!.takenToday && focusedMedicine!!.todayStatus != "taken") {
                    lastConfirmedMedicineName = focusedMedicine!!.name
                    confirmationPulseId += 1
                    MedicineAlarmScheduler.cancelMedicineAlarms(
                        context = context,
                        medicineIdOrName = focusedMedicine!!.id.ifBlank { focusedMedicine!!.name }
                    )
                    ReminderNotificationHelper.playAlarmSound(context, isConfirmationChime = true)
                    ReminderNotificationHelper.speakMedicineReminder(
                        context = context,
                        language = selectedLanguage,
                        medicineName = focusedMedicine!!.name,
                        customMessage = "Wonderful! You have confirmed taking ${focusedMedicine!!.name}. Your family caregiver dashboard has been updated."
                    )
                    onMarkDoseStatus(focusedMedicine!!, "taken", "${focusedMedicine!!.scheduledTime} – Medicine confirmed")
                }
                focusedMedicine = null
            },
            onSkip = {
                onMarkDoseStatus(focusedMedicine!!, "skipped", "Skipped by patient")
                focusedMedicine = null
            },
            onSnooze = {
                onMarkDoseStatus(focusedMedicine!!, "snoozed", "Snoozed 15 min")
                MedicineAlarmScheduler.scheduleDelayReminder(
                    context = context,
                    medicineName = focusedMedicine!!.name,
                    dosage = focusedMedicine!!.dosage,
                    scheduledTime = focusedMedicine!!.scheduledTime,
                    instructions = focusedMedicine!!.mealInstruction,
                    patientName = focusedMedicine!!.patientName,
                    language = selectedLanguage,
                    delaySeconds = 15 * 60,
                    isCaregiverEscalation = false,
                    voiceEnabled = true,
                    triggerImmediately = false
                )
                ReminderNotificationHelper.sendDoseReminderNotification(
                    context = context,
                    title = "Snoozed 15m via AlarmManager: ${focusedMedicine!!.name}",
                    body = "AlarmManager scheduled reminder in 15 minutes for ${focusedMedicine!!.patientName}: Take ${focusedMedicine!!.dosage}",
                    playAlarm = true
                )
                focusedMedicine = null
            },
            onClose = { focusedMedicine = null }
        )
        return
    }

    val totalCount = patientMedicines.size.coerceAtLeast(1)
    val takenCount = patientMedicines.count { it.takenToday || it.todayStatus == "taken" }
    val unconfirmedCount = patientMedicines.count { !it.takenToday && it.todayStatus != "taken" }
    val nextDueMedicine = patientMedicines.firstOrNull { !it.takenToday && it.todayStatus != "taken" }
    val patientShortName = activeMember?.name?.substringBefore(" (") ?: "Mr. Rao"

    val currentDateText = remember {
        SimpleDateFormat("EEEE, MMM d, yyyy", Locale.ENGLISH).format(Date())
    }
    val confirmationTimestamps = remember { androidx.compose.runtime.mutableStateMapOf<String, String>() }

    val greetingText = when {
        selectedLanguage.contains("Hindi", ignoreCase = true) -> "सुप्रभात, $patientShortName!"
        selectedLanguage.contains("Telugu", ignoreCase = true) -> "శుభోదయం, $patientShortName గారు!"
        else -> "Good morning, $patientShortName!"
    }
    val subGreetingText = when {
        selectedLanguage.contains("Hindi", ignoreCase = true) -> "अपनी दवाएं समय पर लें!"
        selectedLanguage.contains("Telugu", ignoreCase = true) -> "మీ మందులను సమయానికి వేసుకోండి!"
        else -> "Take your medicines on time!"
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("patient_today_list"),
        contentPadding = PaddingValues(bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Deep Teal Top Bar + Greeting Hero Card (Matches Screen 1 of MediMate_Elder_Care_App_Dashboard)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF0A5C52),
                                Color(0xFF0E7C6B),
                                Color(0xFF159984)
                            )
                        )
                    )
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header Row: Heart-ECG Icon + "MediMate" + Language Chips + Bell with Red Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF23B59E)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = "MediMate Logo",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Text(
                            text = "MediMate",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Language quick toggle (English / Hindi / Telugu)
                        listOf("EN" to "English", "हिं" to "Hindi", "తె" to "Telugu").forEach { (shortCode, fullLang) ->
                            val isSelected = selectedLanguage.startsWith(fullLang, ignoreCase = true)
                            Surface(
                                onClick = { onLanguageChange(fullLang) },
                                shape = RoundedCornerShape(50),
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.18f)
                            ) {
                                Text(
                                    text = shortCode,
                                    color = if (isSelected) MedTealDark else Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        // Bell Icon with Red Notification Count Badge
                        Box(
                            modifier = Modifier
                                .clickable {
                                    val medName = nextDueMedicine?.name ?: "Metformin 500 mg"
                                    ReminderNotificationHelper.playAlarmSound(context, isConfirmationChime = false)
                                    ReminderNotificationHelper.speakMedicineReminder(
                                        context = context,
                                        language = selectedLanguage,
                                        medicineName = medName
                                    )
                                }
                                .padding(4.dp)
                                .testTag("voice_alarm_bell_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Reminders & Voice Alert",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                            if (unconfirmedCount > 0) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .align(Alignment.TopEnd)
                                        .offset(x = 2.dp, y = (-2).dp)
                                        .clip(CircleShape)
                                        .background(MedAlertRed),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = unconfirmedCount.toString(),
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Patient Portrait + Greeting Card ("Good evening, Mr. Rao / Take your medicines on time!")
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color.White.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.mr_rao_avatar),
                            contentDescription = "Patient Portrait",
                            modifier = Modifier
                                .size(78.dp)
                                .clip(CircleShape)
                                .border(2.5.dp, Color.White, CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentDateText,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White.copy(alpha = 0.88f),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("dashboard_current_date")
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = greetingText,
                                style = MaterialTheme.typography.headlineSmall,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                lineHeight = 28.sp,
                                modifier = Modifier.testTag("dashboard_greeting_text")
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$subGreetingText • Profile: ${activeMember?.bloodGroup ?: "O+"}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.92f)
                            )
                        }
                        IconButton(
                            onClick = {
                                val targetMed = nextDueMedicine ?: patientMedicines.firstOrNull()
                                ReminderNotificationHelper.playAlarmSound(context, isConfirmationChime = false)
                                ReminderNotificationHelper.speakMedicineReminder(
                                    context = context,
                                    language = selectedLanguage,
                                    medicineName = targetMed?.name ?: "scheduled medicine"
                                )
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.22f))
                                .testTag("speak_voice_reminder_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Speak Voice Reminder",
                                tint = Color.White
                            )
                        }
                    }
                }

                // Patient Switcher if multiple elderly relatives exist
                if (familyMembers.size > 1) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        familyMembers.forEach { member ->
                            val selected = member.id == activeMember?.id
                            FilterChip(
                                selected = selected,
                                onClick = { onSelectMember(member.id) },
                                label = {
                                    Text(
                                        text = member.name,
                                        color = if (selected) MedTealDark else Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color.White,
                                    containerColor = Color.White.copy(alpha = 0.15f)
                                )
                            )
                        }
                    }
                }
            }
        }

        // Calming Lottie Dose-Confirmed Feedback Card when a medicine is marked 'Taken'
        item {
            AnimatedVisibility(visible = lastConfirmedMedicineName != null) {
                CalmDoseConfirmedLottieBanner(
                    medicineName = lastConfirmedMedicineName ?: "",
                    pulseId = confirmationPulseId,
                    onDismiss = { lastConfirmedMedicineName = null }
                )
            }
        }

        // Section Header: Today's Medicines + item count (Matches Screen 1)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = MedTealDark,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Today's Medicines",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                Text(
                    text = "${patientMedicines.size} items",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Medicine Cards (Amlodipine 5 mg [Taken], Metformin 500 mg [Due now], Vitamin D [Upcoming], etc.)
        itemsIndexed(
            patientMedicines,
            key = { _, med -> med.id.ifBlank { med.name + med.scheduledTime } }
        ) { index, med ->
            Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                SeniorMedicineScheduleCard(
                    medicine = med,
                    index = index,
                    confirmedTimestamp = confirmationTimestamps[med.id] ?: if (med.takenToday || med.todayStatus == "taken") med.scheduledTime else null,
                    onCardClick = { focusedMedicine = med },
                    onConfirmDose = {
                        // Prevent duplicate confirmations for the same scheduled dose
                        if (!med.takenToday && med.todayStatus != "taken") {
                            val nowTime = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())
                            confirmationTimestamps[med.id] = nowTime
                            lastConfirmedMedicineName = med.name
                            confirmationPulseId += 1
                            MedicineAlarmScheduler.cancelMedicineAlarms(
                                context = context,
                                medicineIdOrName = med.id.ifBlank { med.name }
                            )
                            ReminderNotificationHelper.playAlarmSound(context, isConfirmationChime = true)
                            ReminderNotificationHelper.speakMedicineReminder(
                                context = context,
                                language = selectedLanguage,
                                medicineName = med.name,
                                customMessage = "Confirmed! You took ${med.name} at $nowTime. Your caregiver dashboard has been updated."
                            )
                            onMarkDoseStatus(med, "taken", "$nowTime – Medicine confirmed (${med.name})")
                        }
                    },
                    onSkipDose = {
                        if (!med.takenToday && med.todayStatus != "taken") {
                            onMarkDoseStatus(med, "skipped", "${med.scheduledTime} – Dose marked as Skipped")
                        }
                    },
                    onAskVoiceExplanation = { onRequestQuickGuide(med) }
                )
            }
        }

        // Giant Accessible "Taken / I TOOK MY MEDICINE" Button with integrated Lottie calming success effect
        item {
            val allConfirmed = nextDueMedicine == null
            LottieDashboardTakenButton(
                allConfirmed = allConfirmed,
                nextMedicineName = nextDueMedicine?.name ?: "",
                pulseId = confirmationPulseId,
                onConfirmNextDose = {
                    val target = nextDueMedicine
                    if (target != null && !target.takenToday && target.todayStatus != "taken") {
                        val nowTime = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())
                        confirmationTimestamps[target.id] = nowTime
                        lastConfirmedMedicineName = target.name
                        confirmationPulseId += 1
                        MedicineAlarmScheduler.cancelMedicineAlarms(
                            context = context,
                            medicineIdOrName = target.id.ifBlank { target.name }
                        )
                        ReminderNotificationHelper.playAlarmSound(context, isConfirmationChime = true)
                        ReminderNotificationHelper.speakMedicineReminder(
                            context = context,
                            language = selectedLanguage,
                            medicineName = target.name,
                            customMessage = "Great job, $patientShortName! ${target.name} has been marked as taken at $nowTime."
                        )
                        onMarkDoseStatus(target, "taken", "$nowTime – Medicine confirmed (${target.name})")
                    }
                }
            )
        }

        // Daily Progress Card (Matches Screen 1 bottom: 67% circular ring + "Daily Progress / 2 of 3 taken" + bar chart icon)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    AdherenceRingProgress(
                        taken = takenCount,
                        total = totalCount,
                        modifier = Modifier.size(74.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Daily Progress",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "$takenCount of $totalCount taken",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.BarChart,
                        contentDescription = "Progress Chart",
                        tint = Color(0xFF0E7C6B),
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }

        // AI Multilingual Explanation Banner when active
        item {
            AnimatedVisibility(visible = quickGuideState !is AiTaskState.Idle) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MedTealContainer.copy(alpha = 0.7f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "MediMate AI Voice & Text Guide",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MedTealDark
                            )
                            IconButton(onClick = onDismissQuickGuide) {
                                Icon(Icons.Default.Close, contentDescription = "Close")
                            }
                        }
                        when (quickGuideState) {
                            is AiTaskState.Loading -> {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                    Text("MediMate AI is explaining this medicine...")
                                }
                            }
                            is AiTaskState.Success -> {
                                Text(text = quickGuideState.data, style = MaterialTheme.typography.bodyLarge)
                            }
                            is AiTaskState.Error -> {
                                Text(text = quickGuideState.message, color = MaterialTheme.colorScheme.error)
                            }
                            AiTaskState.Idle -> {}
                        }
                    }
                }
            }
        }

        // Interactive Demo & Alarm Simulation Controls (Section 16 Requirement)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF6F4)),
                border = BorderStroke(1.dp, MedTealPrimary.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = if (isDemoMode) {
                            "[DEMO MODE — SIMULATED NOTIFICATIONS] Interactive Simulation Controls"
                        } else {
                            "Interactive Reminder, Voice & Missed-Dose Simulator"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MedTealDark
                    )
                    Text(
                        text = "Test taking a dose, triggering the 30-minute grace period missed-dose detector, or playing the audible alarm & spoken voice reminder.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val target = nextDueMedicine ?: patientMedicines.firstOrNull()
                                if (target != null && !target.takenToday) {
                                    ReminderNotificationHelper.playAlarmSound(context, isConfirmationChime = true)
                                    onMarkDoseStatus(target, "taken", "[SIMULATED] ${target.scheduledTime} – Medicine confirmed")
                                }
                            },
                            modifier = Modifier.testTag("simulate_take_medicine_btn")
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Simulate Take Dose")
                        }

                        OutlinedButton(
                            onClick = {
                                val target = patientMedicines.lastOrNull() ?: return@OutlinedButton
                                ReminderNotificationHelper.playAlarmSound(context, isConfirmationChime = false)
                                ReminderNotificationHelper.sendDoseReminderNotification(
                                    context = context,
                                    title = "[SIMULATED] Caregiver Missed-Dose Alert (8:30 PM)",
                                    body = "Medication reminder: The scheduled ${target.scheduledTime} dose (${target.name}) for $patientShortName has not been confirmed after the 30m grace period.",
                                    playAlarm = false
                                )
                                onSimulateMissedDoseAlert(target)
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MedAlertRed),
                            modifier = Modifier.testTag("simulate_missed_dose_btn")
                        ) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Simulate Missed Dose & Alert")
                        }

                        OutlinedButton(
                            onClick = {
                                val target = nextDueMedicine ?: patientMedicines.firstOrNull()
                                MedicineAlarmScheduler.scheduleDelayReminder(
                                    context = context,
                                    medicineName = target?.name ?: "Metformin 500 mg",
                                    dosage = target?.dosage ?: "1 tablet",
                                    scheduledTime = target?.scheduledTime ?: "1:00 PM",
                                    instructions = target?.mealInstruction ?: "After Lunch",
                                    patientName = patientShortName,
                                    language = selectedLanguage,
                                    delaySeconds = 2,
                                    isCaregiverEscalation = false,
                                    voiceEnabled = true,
                                    triggerImmediately = true
                                )
                            },
                            modifier = Modifier.testTag("simulate_voice_alarm_btn")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Trigger AlarmManager & Voice ($selectedLanguage)")
                        }
                    }
                }
            }
        }
    }

    if (showAddMedicineDialog) {
        AddMedicineDialog(
            patientName = activeMember?.name ?: "Mr. Rao",
            onDismiss = { showAddMedicineDialog = false },
            onConfirm = { name, dosage, slot, time, meal, condition, mechanism ->
                onAddMedicine(
                    activeMember?.id ?: "demo_mr_rao",
                    activeMember?.name ?: "Mr. Rao",
                    name,
                    dosage,
                    slot,
                    time,
                    meal,
                    condition,
                    mechanism
                )
                showAddMedicineDialog = false
            }
        )
    }
}

/**
 * Screen 2 from MediMate_Elder_Care_App_Dashboard: "My Medicines" dedicated management view
 */
@Composable
fun MyMedicinesScreen(
    patientName: String,
    activeMemberId: String,
    medicines: List<Medicine>,
    selectedLanguage: String,
    onAddMedicine: (String, String, String, String, String, String, String, String, String) -> Unit,
    onDeleteMedicine: (String) -> Unit
) {
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Deep Teal Header matching Screen 2 ("My Medicines" + "+" button)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A5C52))
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "My Medicines",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Prescribed Schedule for $patientName",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
                IconButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .testTag("header_add_medicine_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Medicine",
                        tint = Color(0xFF0A5C52)
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("my_medicines_list"),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            itemsIndexed(medicines, key = { _, m -> m.id.ifBlank { m.name } }) { index, med ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            TwoToneCapsuleIcon(index = index)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = med.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = med.dosage,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AccessTime,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = MedTealDark
                                    )
                                    Text(
                                        text = "${med.scheduledTime} • ${med.mealInstruction}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color(0xFFDFF5E6)
                            ) {
                                Text(
                                    text = "Active",
                                    color = MedTakenGreen,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelLarge,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Stock: ${med.stockRemaining} left • Condition: ${med.conditionTag}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            TextButton(
                                onClick = {
                                    ReminderNotificationHelper.speakMedicineReminder(
                                        context = context,
                                        language = selectedLanguage,
                                        medicineName = med.name
                                    )
                                }
                            ) {
                                Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Speak")
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { showAddDialog = true },
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0A5C52),
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .testTag("bottom_add_medicine_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Add Medicine",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(64.dp))
            }
        }
    }

    if (showAddDialog) {
        AddMedicineDialog(
            patientName = patientName,
            onDismiss = { showAddDialog = false },
            onConfirm = { name, dosage, slot, time, meal, condition, mechanism ->
                onAddMedicine(
                    activeMemberId,
                    patientName,
                    name,
                    dosage,
                    slot,
                    time,
                    meal,
                    condition,
                    mechanism
                )
                showAddDialog = false
            }
        )
    }
}

/**
 * 2-Tone Capsule Pill Icon matching Screen 1 & Screen 2 of MediMate_Elder_Care_App_Dashboard
 */
@Composable
fun TwoToneCapsuleIcon(index: Int) {
    val primaryPillColor = when (index % 4) {
        0 -> Color(0xFF2B80FF) // Blue capsule (Amlodipine)
        1 -> Color(0xFFFF9838) // Orange capsule (Metformin)
        2 -> Color(0xFF6B5AED) // Purple capsule (Vitamin D)
        else -> Color(0xFFF06292) // Pink capsule (Calcium)
    }
    Box(
        modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(primaryPillColor.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier
                .width(34.dp)
                .height(16.dp)
                .rotate(-35f)
                .clip(RoundedCornerShape(50))
                .border(1.dp, primaryPillColor.copy(alpha = 0.5f), RoundedCornerShape(50))
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .background(primaryPillColor)
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .background(Color.White)
            )
        }
    }
}

@Composable
private fun SeniorMedicineScheduleCard(
    medicine: Medicine,
    index: Int,
    confirmedTimestamp: String? = null,
    onCardClick: () -> Unit,
    onConfirmDose: () -> Unit,
    onSkipDose: () -> Unit = {},
    onAskVoiceExplanation: () -> Unit
) {
    val isTaken = medicine.takenToday || medicine.todayStatus == "taken"
    val isSkipped = medicine.todayStatus == "skipped" && !isTaken
    val isMissed = medicine.todayStatus == "missed" && !isTaken
    val isDueNow = !isTaken && !isSkipped && !isMissed && index == 1 // e.g., 1:00 PM Metformin "Due now"

    val badgeBgColor = when {
        isTaken -> Color(0xFFD9F3E4)
        isSkipped -> Color(0xFFECEFF1)
        isMissed -> Color(0xFFFDE2E1)
        isDueNow -> Color(0xFFFFECCC)
        else -> Color(0xFFE5EEFF)
    }
    val badgeTextColor = when {
        isTaken -> Color(0xFF1B7A43)
        isSkipped -> Color(0xFF455A64)
        isMissed -> MedAlertRed
        isDueNow -> Color(0xFFB85D00)
        else -> Color(0xFF2B50AA)
    }
    val badgeLabel = when {
        isTaken -> "✓ Taken"
        isSkipped -> "⏭ Skipped"
        isMissed -> "⚠ Missed"
        isDueNow -> "🔔 Due now"
        else -> "🕒 Upcoming"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
            .testTag("medicine_card_${medicine.id}"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = if (isDueNow) BorderStroke(1.5.dp, Color(0xFFFF9838)) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                TwoToneCapsuleIcon(index = index)

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = medicine.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Dosage: ${medicine.dosage}",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = MedTealDark
                        )
                        Text(
                            text = "Scheduled: ${medicine.scheduledTime}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MedTealDark
                        )
                    }
                }

                LottieCardTakenButton(
                    medicineId = medicine.id,
                    isTaken = isTaken,
                    isMissed = isMissed,
                    isDueNow = isDueNow,
                    badgeBgColor = badgeBgColor,
                    badgeTextColor = badgeTextColor,
                    badgeLabel = badgeLabel,
                    onConfirmDose = onConfirmDose,
                    onCardClick = onCardClick
                )
            }

            // Instructions & Confirmation Timestamp Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Instructions: ${medicine.mealInstruction}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isTaken && !confirmedTimestamp.isNullOrBlank()) {
                        Text(
                            text = "✓ Confirmed at $confirmedTimestamp",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MedTakenGreen
                        )
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (!isTaken && !isSkipped) {
                        TextButton(
                            onClick = onSkipDose,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.testTag("skip_card_btn_${medicine.id}")
                        ) {
                            Text("Skip", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    TextButton(
                        onClick = onAskVoiceExplanation,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("hindi_guide_btn_${medicine.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ask AI")
                    }
                }
            }

            // Large Accessible "I TOOK MY MEDICINE" Button per Medicine Card (Prevents duplicate confirmation)
            Button(
                onClick = onConfirmDose,
                enabled = !isTaken,
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0E7C6B),
                    contentColor = Color.White,
                    disabledContainerColor = Color(0xFFD9F3E4),
                    disabledContentColor = Color(0xFF1B7A43)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("taken_button_${medicine.id}")
            ) {
                Icon(
                    imageVector = if (isTaken) Icons.Default.CheckCircle else Icons.Default.Check,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isTaken) {
                        "✓ DOSE CONFIRMED (${confirmedTimestamp ?: medicine.scheduledTime})"
                    } else {
                        "I TOOK MY MEDICINE"
                    },
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

/**
 * Interactive 'Taken' status pill / button on each medicine card that triggers a subtle,
 * calming Lottie success animation when a dose is confirmed.
 */
@Composable
private fun LottieCardTakenButton(
    medicineId: String,
    isTaken: Boolean,
    isMissed: Boolean,
    isDueNow: Boolean,
    badgeBgColor: Color,
    badgeTextColor: Color,
    badgeLabel: String,
    onConfirmDose: () -> Unit,
    onCardClick: () -> Unit
) {
    var localTriggerCount by remember { mutableIntStateOf(0) }
    val composition by rememberLottieComposition(
        LottieCompositionSpec.RawRes(R.raw.med_taken_calm_pulse)
    )
    val progress by animateLottieCompositionAsState(
        composition = composition,
        iterations = if (localTriggerCount > 0) 2 else 1,
        speed = 0.8f,
        restartOnPlay = true,
        isPlaying = isTaken || localTriggerCount > 0
    )

    Surface(
        onClick = {
            if (!isTaken) {
                localTriggerCount += 1
                onConfirmDose()
            } else {
                onCardClick()
            }
        },
        shape = RoundedCornerShape(50),
        color = badgeBgColor,
        border = if (isDueNow && !isTaken) BorderStroke(1.dp, Color(0xFFB85D00).copy(alpha = 0.4f)) else null,
        modifier = Modifier.testTag("toggle_taken_$medicineId")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            if (isTaken) {
                LottieAnimation(
                    composition = composition,
                    progress = { progress },
                    modifier = Modifier
                        .size(24.dp)
                        .testTag("card_taken_lottie_$medicineId")
                )
            }
            Text(
                text = if (isTaken) "Taken" else badgeLabel,
                color = badgeTextColor,
                fontWeight = FontWeight.ExtraBold,
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

/**
 * Main Dashboard 'Taken / I TOOK MY MEDICINE' button with embedded calming Lottie success animation.
 */
@Composable
private fun LottieDashboardTakenButton(
    allConfirmed: Boolean,
    nextMedicineName: String,
    pulseId: Int,
    onConfirmNextDose: () -> Unit
) {
    val composition by rememberLottieComposition(
        LottieCompositionSpec.RawRes(R.raw.med_taken_calm_pulse)
    )
    val progress by animateLottieCompositionAsState(
        composition = composition,
        iterations = 2,
        speed = 0.85f,
        restartOnPlay = true,
        isPlaying = pulseId > 0 || allConfirmed
    )

    Button(
        onClick = onConfirmNextDose,
        enabled = !allConfirmed,
        shape = RoundedCornerShape(50),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF0E7C6B),
            contentColor = Color.White,
            disabledContainerColor = MedTakenGreen.copy(alpha = 0.85f),
            disabledContentColor = Color.White
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .height(64.dp)
            .testTag("i_took_my_medicine_button")
    ) {
        if (pulseId > 0 || allConfirmed) {
            LottieAnimation(
                composition = composition,
                progress = { progress },
                modifier = Modifier
                    .size(36.dp)
                    .testTag("dashboard_taken_button_lottie")
            )
            Spacer(modifier = Modifier.width(8.dp))
        } else {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
        }
        Text(
            text = if (allConfirmed) {
                "Taken • All Today's Medicines Confirmed ✓"
            } else {
                "I TOOK MY MEDICINE ($nextMedicineName)"
            },
            fontSize = 17.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

/**
 * Subtle, calming Lottie feedback banner displayed when the user marks a medicine as 'Taken'.
 */
@Composable
private fun CalmDoseConfirmedLottieBanner(
    medicineName: String,
    pulseId: Int,
    onDismiss: () -> Unit
) {
    val composition by rememberLottieComposition(
        LottieCompositionSpec.RawRes(R.raw.med_taken_calm_pulse)
    )
    val progress by animateLottieCompositionAsState(
        composition = composition,
        iterations = 2,
        speed = 0.85f,
        restartOnPlay = true,
        isPlaying = pulseId > 0
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .testTag("lottie_dose_confirmed_banner"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFE7F7EF)
        ),
        border = BorderStroke(1.dp, MedTakenGreen.copy(alpha = 0.35f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LottieAnimation(
                composition = composition,
                progress = { progress },
                modifier = Modifier
                    .size(56.dp)
                    .testTag("lottie_calm_check_animation")
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Dose Confirmed: $medicineName",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF145A32)
                )
                Text(
                    text = "Take a calm breath — your family caregiver dashboard is updated.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF1E7E48)
                )
            }
            IconButton(onClick = onDismiss) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Dismiss confirmation banner",
                    tint = Color(0xFF145A32)
                )
            }
        }
    }
}

/**
 * Subtle inline Lottie checkmark pulse inside the 'Taken' badge on medicine cards.
 */
@Composable
private fun LottieTakenBadgeIcon(modifier: Modifier = Modifier) {
    val composition by rememberLottieComposition(
        LottieCompositionSpec.RawRes(R.raw.med_taken_calm_pulse)
    )
    val progress by animateLottieCompositionAsState(
        composition = composition,
        iterations = LottieConstants.IterateForever,
        speed = 0.55f
    )
    LottieAnimation(
        composition = composition,
        progress = { progress },
        modifier = modifier
    )
}

@Composable
fun AdherenceRingProgress(
    taken: Int,
    total: Int,
    modifier: Modifier = Modifier
) {
    val progress = (taken.toFloat() / total.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 9.dp.toPx()
            drawArc(
                color = Color(0xFFD5EBE6),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            drawArc(
                color = Color(0xFF1F9D55),
                startAngle = -90f,
                sweepAngle = 360f * progress,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }
        Text(
            text = "${(progress * 100).toInt()}%",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = MedTealDark
        )
    }
}

@Composable
fun FocusedElderlyDoseScreen(
    medicine: Medicine,
    allDayMedicines: List<Medicine>,
    onMarkTaken: () -> Unit,
    onSkip: () -> Unit,
    onSnooze: () -> Unit,
    onClose: () -> Unit
) {
    val alreadyTaken = medicine.takenToday || medicine.todayStatus == "taken"
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MediMate • Senior Focus View",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            OutlinedButton(
                onClick = onClose,
                modifier = Modifier.testTag("close_focused_dose_btn")
            ) {
                Text("Back")
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .width(10.dp)
                        .height(190.dp)
                        .background(MedTealPrimary)
                )
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = medicine.scheduledTime,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold,
                        color = MedTealDark
                    )
                    Text(
                        text = medicine.name,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${medicine.dosage} • ${medicine.mealInstruction}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        val composition by rememberLottieComposition(
            LottieCompositionSpec.RawRes(R.raw.med_taken_calm_pulse)
        )
        var clickedTaken by remember { mutableStateOf(alreadyTaken) }
        val lottieProgress by animateLottieCompositionAsState(
            composition = composition,
            iterations = 2,
            speed = 0.85f,
            isPlaying = clickedTaken
        )

        Box(
            modifier = Modifier
                .size(210.dp)
                .clip(CircleShape)
                .background(if (clickedTaken) MedTakenGreen else MedNavyBlue)
                .clickable(enabled = !alreadyTaken) {
                    clickedTaken = true
                    onMarkTaken()
                }
                .testTag("giant_taken_button"),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (clickedTaken) {
                    LottieAnimation(
                        composition = composition,
                        progress = { lottieProgress },
                        modifier = Modifier.size(92.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Mark Taken",
                        tint = Color.White,
                        modifier = Modifier.size(64.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Taken",
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(32.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onSkip, modifier = Modifier.testTag("skip_dose_button")) {
                Text("Skip", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MedNavyBlue)
            }
            TextButton(onClick = onSnooze, modifier = Modifier.testTag("snooze_dose_button")) {
                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MedNavyBlue)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Snooze 15 min", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MedNavyBlue)
            }
        }
    }
}

@Composable
fun AddMedicineDialog(
    patientName: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var dosage by remember { mutableStateOf("1 tablet • Once daily") }
    var timeSlot by remember { mutableStateOf("Morning") }
    var scheduledTime by remember { mutableStateOf("8:00 AM") }
    var doctorName by remember { mutableStateOf("Dr. Reddy") }
    var mealInstruction by remember { mutableStateOf("After Breakfast") }
    var conditionTag by remember { mutableStateOf("BP") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Prescribed Medicine for $patientName") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Enter details exactly as prescribed by your doctor. MediMate never independently alters dosages.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Medicine Name & Strength (e.g. Amlodipine 5 mg)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_medicine_name")
                )
                OutlinedTextField(
                    value = dosage,
                    onValueChange = { dosage = it },
                    label = { Text("Prescribed Dosage & Schedule (e.g. 1 tablet • Once daily)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Morning", "Afternoon", "Night").forEach { slot ->
                        FilterChip(
                            selected = timeSlot == slot,
                            onClick = {
                                timeSlot = slot
                                scheduledTime = when (slot) {
                                    "Morning" -> "8:00 AM"
                                    "Afternoon" -> "1:00 PM"
                                    else -> "8:00 PM"
                                }
                            },
                            label = { Text(slot) }
                        )
                    }
                }
                OutlinedTextField(
                    value = scheduledTime,
                    onValueChange = { scheduledTime = it },
                    label = { Text("Scheduled Time (e.g. 8:00 AM)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = doctorName,
                    onValueChange = { doctorName = it },
                    label = { Text("Prescribing Doctor") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = mealInstruction,
                    onValueChange = { mealInstruction = it },
                    label = { Text("Instructions (e.g. After Breakfast)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(
                            name,
                            dosage,
                            timeSlot,
                            scheduledTime,
                            "$mealInstruction • $doctorName",
                            conditionTag,
                            "Prescribed by $doctorName ($mealInstruction)"
                        )
                    }
                },
                modifier = Modifier.testTag("confirm_add_medicine_btn")
            ) {
                Text("Save Schedule")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
