package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF56D6C4),
    onPrimary = Color(0xFF003731),
    primaryContainer = MedTealDark,
    onPrimaryContainer = MedTealContainer,
    secondary = MedSaffronLight,
    onSecondary = Color(0xFF452100),
    secondaryContainer = Color(0xFF623206),
    onSecondaryContainer = MedSaffronContainer,
    tertiary = Color(0xFF8EC8F6),
    background = MedDarkBackground,
    onBackground = Color(0xFFE5F0EE),
    surface = MedDarkSurface,
    onSurface = Color(0xFFE5F0EE),
    surfaceVariant = MedDarkCard,
    onSurfaceVariant = Color(0xFFBBD0CC),
    error = Color(0xFFFF8983)
)

private val LightColorScheme = lightColorScheme(
    primary = MedTealPrimary,
    onPrimary = Color.White,
    primaryContainer = MedTealContainer,
    onPrimaryContainer = OnMedTealContainer,
    secondary = MedSaffron,
    onSecondary = Color.White,
    secondaryContainer = MedSaffronContainer,
    onSecondaryContainer = OnMedSaffronContainer,
    tertiary = MedNavyBlue,
    onTertiary = Color.White,
    tertiaryContainer = MedNavyContainer,
    onTertiaryContainer = MedNavyDark,
    background = MedCreamBackground,
    onBackground = Color(0xFF14211F),
    surface = MedSurfaceCard,
    onSurface = Color(0xFF14211F),
    surfaceVariant = MedMintSurface,
    onSurfaceVariant = Color(0xFF3D524F),
    error = MedAlertRed,
    onError = Color.White
)

@Composable
fun MedMateTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
