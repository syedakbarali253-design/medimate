package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MedMate Palette — Inspired by the uploaded Indian Family Care screenshots:
// Warm Ivory / Cream surfaces, Deep Healing Teal & Navy primary accents,
// Warm Saffron / Marigold family header gradients, and High-Contrast Elderly-friendly tokens.

val MedTealPrimary = Color(0xFF147A6E)
val MedTealDark = Color(0xFF0C5249)
val MedTealContainer = Color(0xFFD6F3EE)
val OnMedTealContainer = Color(0xFF073B34)

val MedNavyBlue = Color(0xFF135078)
val MedNavyDark = Color(0xFF1D244B)
val MedNavyContainer = Color(0xFFD9E9F7)

val MedSaffron = Color(0xFFE07A2E)
val MedSaffronLight = Color(0xFFF3A257)
val MedSaffronContainer = Color(0xFFFFECD9)
val OnMedSaffronContainer = Color(0xFF4A2204)

val MedCreamBackground = Color(0xFFFBF8F2)
val MedSurfaceCard = Color(0xFFFFFFFF)
val MedMintSurface = Color(0xFFF1F9F7)
val MedMintBar = Color(0xFF83CBC0)

val MedTakenGreen = Color(0xFF2E8B57)
val MedTakenGreenSoft = Color(0xFFE4F5EC)
val MedAlertRed = Color(0xFFD63835)
val MedAlertRedSoft = Color(0xFFFDE8E8)
val MedAmberWarning = Color(0xFFD9822B)

val MedDarkBackground = Color(0xFF0F1918)
val MedDarkSurface = Color(0xFF172624)
val MedDarkCard = Color(0xFF1F3330)
