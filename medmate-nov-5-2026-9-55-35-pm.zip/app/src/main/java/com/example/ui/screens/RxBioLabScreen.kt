package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Biotech
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.BioscienceReport
import com.example.data.model.FamilyMember
import com.example.data.model.Medicine
import com.example.data.model.ScannedPrescriptionMedicine
import com.example.ui.theme.MedAlertRed
import com.example.ui.theme.MedNavyBlue
import com.example.ui.theme.MedNavyDark
import com.example.ui.theme.MedSaffron
import com.example.ui.theme.MedTakenGreen
import com.example.ui.theme.MedTealContainer
import com.example.ui.theme.MedTealPrimary
import com.example.util.ReminderNotificationHelper
import com.example.viewmodel.AiTaskState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RxBioLabScreen(
    familyMembers: List<FamilyMember>,
    selectedMemberId: String?,
    medicines: List<Medicine>,
    selectedLanguage: String = "English",
    scannedState: AiTaskState<List<ScannedPrescriptionMedicine>>,
    bioscienceState: AiTaskState<BioscienceReport>,
    aiAssistantState: AiTaskState<String> = AiTaskState.Idle,
    onAskAiAssistant: (String, String) -> Unit = { _, _ -> },
    onScanPrescription: (String, Bitmap?) -> Unit,
    onImportScannedMedicine: (ScannedPrescriptionMedicine) -> Unit,
    onRunDeepBioscienceAnalysis: () -> Unit
) {
    val context = LocalContext.current
    val activeMember = familyMembers.find { it.id == selectedMemberId } ?: familyMembers.firstOrNull()

    var rawOcrText by remember {
        mutableStateOf(
            """
            Apollo Heart & Diabetes Clinic, Hyderabad
            Patient: Mr. S. Rao (72Y / M) | Dx: Essential HTN, Type 2 Diabetes
            Rx:
            1. Tab. Amlodipine 5 mg — 1 tablet Once daily at 8:00 AM After Breakfast
            2. Tab. Metformin 500 mg — 1 tablet Twice daily at 1:00 PM & 8:00 PM After Meals
            3. Cap. Vitamin D 60k IU — 1 capsule Daily at 8:00 PM After Dinner
            4. Tab. Calcium 600 mg — 1 tablet Daily at 9:00 PM Before Bedtime
            """.trimIndent()
        )
    }
    var selectedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    var assistantQuestion by remember {
        mutableStateOf("Explain Mr. Rao's Amlodipine 5 mg and Metformin 500 mg schedule in simple terms.")
    }
    var assistantLang by remember(selectedLanguage) { mutableStateOf(selectedLanguage) }

    // Editable review list for OCR items so uncertain OCR output is NEVER activated without user review
    val editableScannedList = remember { mutableStateListOf<ScannedPrescriptionMedicine>() }
    LaunchedEffect(scannedState) {
        if (scannedState is AiTaskState.Success) {
            editableScannedList.clear()
            editableScannedList.addAll(scannedState.data)
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            try {
                val bmp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                        decoder.isMutableRequired = true
                    }
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                }
                selectedBitmap = bmp
            } catch (_: Exception) {
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("rx_biolab_list"),
        contentPadding = PaddingValues(bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Deep Teal Top Bar
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0A5C52))
                    .padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "MediMate AI Assistant & Rx Scanner",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Multilingual Voice Assistant (EN / हिंदी / తెలుగు) • Editable Rx OCR • Pharmacology Lab",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }
        }

        // Mandatory Medical Safety Disclaimer Banner
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFFFF8E1),
                border = BorderStroke(1.dp, Color(0xFFFFB300))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.HealthAndSafety,
                        contentDescription = null,
                        tint = Color(0xFFE65100),
                        modifier = Modifier.size(26.dp)
                    )
                    Column {
                        Text(
                            text = "Medical & Clinical Safety Notice",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFE65100)
                        )
                        Text(
                            text = "MediMate helps explain prescribed schedules and reminders. It never diagnoses diseases, never prescribes medicines, and never recommends changing or doubling a missed dose. Always consult your prescribing doctor.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MedNavyDark
                        )
                    }
                }
            }
        }

        // Card 1: MediMate AI Health Assistant (English, Hindi, Telugu)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = MedTealPrimary
                        )
                        Column {
                            Text(
                                text = "1. MediMate AI Health Assistant",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "Ask about ${activeMember?.name ?: "Mr. Rao"}'s schedule in English, Hindi (हिंदी), or Telugu (తెలుగు)",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("English", "Hindi", "Telugu").forEach { lang ->
                            FilterChip(
                                selected = assistantLang == lang,
                                onClick = { assistantLang = lang },
                                label = { Text(lang, fontWeight = FontWeight.Bold) }
                            )
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AssistChip(
                            onClick = {
                                assistantQuestion = "What medicines are scheduled for Mr. Rao today and when?"
                                onAskAiAssistant(assistantQuestion, assistantLang)
                            },
                            label = { Text("Today's Schedule") }
                        )
                        AssistChip(
                            onClick = {
                                assistantQuestion = "What should we do if the 8:00 PM Metformin dose was not confirmed?"
                                onAskAiAssistant(assistantQuestion, assistantLang)
                            },
                            label = { Text("Missed Dose Guidance") }
                        )
                        AssistChip(
                            onClick = {
                                assistantQuestion = "Why is Metformin taken with meals and Amlodipine in the morning?"
                                onAskAiAssistant(assistantQuestion, assistantLang)
                            },
                            label = { Text("Food & Timing Instructions") }
                        )
                    }

                    OutlinedTextField(
                        value = assistantQuestion,
                        onValueChange = { assistantQuestion = it },
                        label = { Text("Ask MediMate Assistant ($assistantLang)") },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_assistant_input")
                    )

                    Button(
                        onClick = { onAskAiAssistant(assistantQuestion, assistantLang) },
                        enabled = aiAssistantState !is AiTaskState.Loading && assistantQuestion.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A8770)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ask_ai_assistant_btn")
                    ) {
                        if (aiAssistantState is AiTaskState.Loading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generating Safe Explanation...")
                        } else {
                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Ask MediMate AI ($assistantLang)")
                        }
                    }

                    when (aiAssistantState) {
                        is AiTaskState.Error -> {
                            Text(
                                text = aiAssistantState.message,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        is AiTaskState.Success -> {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MedTealContainer.copy(alpha = 0.55f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "MediMate Response ($assistantLang)",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MedTealPrimary
                                        )
                                        TextButton(
                                            onClick = {
                                                ReminderNotificationHelper.speakMedicineReminder(
                                                    context = context,
                                                    language = assistantLang,
                                                    medicineName = "Metformin 500 mg"
                                                )
                                            }
                                        ) {
                                            Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Read Aloud")
                                        }
                                    }
                                    Text(
                                        text = aiAssistantState.data,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MedNavyDark
                                    )
                                }
                            }
                        }
                        else -> {}
                    }
                }
            }
        }

        // Card 2: Prescription OCR + Editable Review Screen before Schedule Activation
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DocumentScanner,
                            contentDescription = null,
                            tint = MedTealPrimary
                        )
                        Column {
                            Text(
                                text = "2. Prescription Scanner & Editable Review",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "Patient target: ${activeMember?.name ?: "Mr. Rao"} • Review & edit extracted fields before confirming",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (selectedBitmap != null) {
                        Image(
                            bitmap = selectedBitmap!!.asImageBitmap(),
                            contentDescription = "Selected Prescription Image",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(14.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }

                    OutlinedTextField(
                        value = rawOcrText,
                        onValueChange = { rawOcrText = it },
                        label = { Text("Prescription OCR Text / Doctor Notes (OD, BD, BBF, HS)") },
                        minLines = 4,
                        maxLines = 7,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("rx_ocr_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("pick_rx_photo_btn")
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Upload Rx Image")
                        }

                        Button(
                            onClick = { onScanPrescription(rawOcrText, selectedBitmap) },
                            enabled = scannedState !is AiTaskState.Loading,
                            colors = ButtonDefaults.buttonColors(containerColor = MedTealPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("scan_rx_ai_btn")
                        ) {
                            if (scannedState is AiTaskState.Loading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Scanning...")
                            } else {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Scan & Review")
                            }
                        }
                    }

                    when (scannedState) {
                        is AiTaskState.Error -> {
                            Text(
                                text = scannedState.message,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        is AiTaskState.Success -> {
                            HorizontalDivider()
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFFFF8E1),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Editable Review Screen: Please verify medicine name, dosage, and time against the doctor's prescription before tapping 'Confirm & Add'.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFE65100),
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }

                            editableScannedList.forEachIndexed { idx, scannedMed ->
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = MedTealContainer.copy(alpha = 0.35f),
                                    border = BorderStroke(1.dp, MedTealPrimary.copy(alpha = 0.3f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedTextField(
                                                value = scannedMed.name,
                                                onValueChange = { newName ->
                                                    editableScannedList[idx] = scannedMed.copy(name = newName)
                                                },
                                                label = { Text("Medicine Name") },
                                                singleLine = true,
                                                modifier = Modifier.weight(1.3f)
                                            )
                                            OutlinedTextField(
                                                value = scannedMed.dosage,
                                                onValueChange = { newDosage ->
                                                    editableScannedList[idx] = scannedMed.copy(dosage = newDosage)
                                                },
                                                label = { Text("Dosage") },
                                                singleLine = true,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedTextField(
                                                value = scannedMed.scheduledTime,
                                                onValueChange = { newTime ->
                                                    editableScannedList[idx] = scannedMed.copy(scheduledTime = newTime)
                                                },
                                                label = { Text("Scheduled Time") },
                                                singleLine = true,
                                                modifier = Modifier.weight(1f)
                                            )
                                            OutlinedTextField(
                                                value = scannedMed.mealInstruction,
                                                onValueChange = { newMeal ->
                                                    editableScannedList[idx] = scannedMed.copy(mealInstruction = newMeal)
                                                },
                                                label = { Text("Instructions") },
                                                singleLine = true,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Slot: ${scannedMed.timeSlot} • ${scannedMed.conditionTag}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MedNavyBlue,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Button(
                                                onClick = { onImportScannedMedicine(editableScannedList[idx]) },
                                                colors = ButtonDefaults.buttonColors(containerColor = MedTakenGreen),
                                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                                            ) {
                                                Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Confirm & Add")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else -> {}
                    }
                }
            }
        }

        // Card 3: Deep Bioscience & Polypharmacy High-Thinking Analysis (gemini-4-argon + ThinkingLevel.HIGH)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MedNavyDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Biotech,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "3. Bioscience & Polypharmacy Deep Reasoning",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Powered by Gemini 4 Argon (High Thinking) • Analyzes CYP450, AMPK/L-type Ca2+ pathways & Indian food-drug timing",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Button(
                        onClick = onRunDeepBioscienceAnalysis,
                        enabled = bioscienceState !is AiTaskState.Loading,
                        colors = ButtonDefaults.buttonColors(containerColor = MedNavyDark),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("run_bioscience_analysis_btn")
                    ) {
                        if (bioscienceState is AiTaskState.Loading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Running High-Thinking Bioscience Analysis...")
                        } else {
                            Icon(Icons.Default.Science, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Analyze ${activeMember?.name ?: "Mr. Rao"}'s Regimen (${medicines.size} Meds)")
                        }
                    }

                    when (bioscienceState) {
                        is AiTaskState.Error -> {
                            Text(
                                text = bioscienceState.message,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        is AiTaskState.Success -> {
                            val report = bioscienceState.data
                            HorizontalDivider()
                            Text(
                                text = "Clinical Pharmacology Synthesis",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MedNavyDark
                            )
                            Text(
                                text = report.clinicalSummary,
                                style = MaterialTheme.typography.bodyMedium
                            )

                            if (report.pharmacokineticPathways.isNotEmpty()) {
                                Text(
                                    text = "Molecular & Receptor Pathways (PK/PD)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MedTealPrimary
                                )
                                report.pharmacokineticPathways.forEach { item ->
                                    Text("• $item", style = MaterialTheme.typography.bodyMedium)
                                }
                            }

                            if (report.drugFoodInteractions.isNotEmpty()) {
                                Text(
                                    text = "Indian Diet & Food-Drug Interactions",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MedSaffron
                                )
                                report.drugFoodInteractions.forEach { item ->
                                    Text("• $item", style = MaterialTheme.typography.bodyMedium)
                                }
                            }

                            if (report.chronoPharmacologyTip.isNotBlank()) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MedTealContainer.copy(alpha = 0.5f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = "Chronopharmacology Timing Tip",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = MedTealPrimary
                                        )
                                        Text(
                                            text = report.chronoPharmacologyTip,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                }
                            }

                            if (report.geriatricSafetyAlerts.isNotEmpty()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.WarningAmber,
                                        contentDescription = null,
                                        tint = MedAlertRed,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "Geriatric Monitoring Checkpoints",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MedAlertRed
                                    )
                                }
                                report.geriatricSafetyAlerts.forEach { alert ->
                                    Text("• $alert", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                        else -> {}
                    }
                }
            }
        }
    }
}
