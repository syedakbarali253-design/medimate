package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.DoseLog
import com.example.data.model.FamilyMember
import com.example.data.model.Medicine
import com.example.data.model.UserProfile
import com.example.service.MediMateFcmManager
import com.example.ui.theme.MedAlertRed
import com.example.ui.theme.MedNavyBlue
import com.example.ui.theme.MedSaffron
import com.example.ui.theme.MedTakenGreen
import com.example.ui.theme.MedTealDark
import com.example.ui.theme.MedTealPrimary
import com.example.util.ReminderNotificationHelper

/**
 * Screen 3 ("Family Dashboard") from MediMate_Elder_Care_App_Dashboard__1__ccc801df.png:
 * - Deep Teal Header ("Family Dashboard")
 * - Connected Caregiver Profile Card: Anita Rao (Daughter • ✓ Connected)
 * - "Medication Progress Today": 75% ring + "3 of 4 confirmed"
 * - Unconfirmed Dose Alert Card: "8:00 PM dose not confirmed / Tap to contact patient" + red "📞 Contact Patient" button
 * - "Recent Activity":
 *   - 8:00 AM – Medicine confirmed
 *   - 1:00 PM – Medicine confirmed
 *   - 8:30 PM – Alert sent
 */
@Composable
fun CaregiverDashboardScreen(
    userProfile: UserProfile?,
    familyMembers: List<FamilyMember>,
    medicines: List<Medicine>,
    doseLogs: List<DoseLog>,
    onSelectPatientForTodayView: (String) -> Unit,
    onSendNudgeAlert: (String) -> Unit
) {
    val context = LocalContext.current
    val activePatient = familyMembers.firstOrNull()
    val patientMeds = remember(medicines, activePatient) {
        if (activePatient != null) {
            val filtered = medicines.filter { it.memberId == activePatient.id || it.patientName == activePatient.name }
            if (filtered.isNotEmpty()) filtered else medicines
        } else {
            medicines
        }
    }

    val totalDoses = patientMeds.size.coerceAtLeast(4)
    val confirmedDoses = patientMeds.count { it.takenToday || it.todayStatus == "taken" }.coerceAtLeast(1)
    val unconfirmedMed = patientMeds.firstOrNull { !it.takenToday && it.todayStatus != "taken" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("caregiver_dashboard_list"),
        contentPadding = PaddingValues(bottom = 92.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Deep Teal Top Bar matching Screen 3 ("Family Dashboard")
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0A5C52))
                    .padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Family Dashboard",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Icon(
                        imageVector = Icons.Default.Groups,
                        contentDescription = "Connected Family",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        // Anita Rao (Daughter • Connected) Header Card matching Screen 3
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFD9F2EE))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.anita_rao_avatar),
                            contentDescription = "Anita Rao Portrait",
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .border(2.5.dp, Color.White, CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Anita Rao",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF0B3B35)
                            )
                            Text(
                                text = "Daughter • Caregiver for ${activePatient?.name ?: "Mr. Rao"}",
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color(0xFF285952)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color(0xFFC2EBD5)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = MedTakenGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "Connected",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MedTakenGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    if (familyMembers.size > 1) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            familyMembers.forEach { member ->
                                FilterChip(
                                    selected = member.id == activePatient?.id,
                                    onClick = { onSelectPatientForTodayView(member.id) },
                                    label = { Text("Monitoring: ${member.name}") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MedTealDark,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier.testTag("family_card_${member.id}")
                                )
                            }
                        }
                    }
                }
            }
        }

        // Medication Progress Today Card (Matches Screen 3: 75% ring + "3 of 4 confirmed")
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Medication Progress Today",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        AdherenceRingProgress(
                            taken = confirmedDoses,
                            total = totalDoses,
                            modifier = Modifier.size(88.dp)
                        )
                        Column {
                            Text(
                                text = "$confirmedDoses of $totalDoses",
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "confirmed",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Next Medicine: ${unconfirmedMed?.scheduledTime ?: "8:00 PM"}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MedTealPrimary
                            )
                        }
                    }
                }
            }
        }

        // Missed / Unconfirmed Dose Alert Card (Matches Screen 3: "8:00 PM dose not confirmed / Tap to contact patient" + Red "Contact Patient" button)
        item {
            val unconfirmedTime = unconfirmedMed?.scheduledTime ?: "8:00 PM"
            val unconfirmedName = unconfirmedMed?.name ?: "Prescribed medicine"
            val patientName = activePatient?.name ?: "Mr. Rao"
            val patientPhone = activePatient?.phone ?: "+91 98480 11223"

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .testTag("missed_dose_alert_banner"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFDECEB)),
                border = BorderStroke(1.dp, MedAlertRed.copy(alpha = 0.35f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Unconfirmed Dose Alert",
                            tint = MedAlertRed,
                            modifier = Modifier.size(36.dp)
                        )
                        Column {
                            Text(
                                text = "$unconfirmedTime dose\nnot confirmed",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFB71C1C),
                                lineHeight = 24.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Tap to contact patient ($patientName • $unconfirmedName)",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF5D4037)
                            )
                        }
                    }

                    Text(
                        text = "Medication reminder: The scheduled $unconfirmedTime dose for your connected family member has not been confirmed after the 30-minute grace period. Note: Do not advise taking a double or extra dose.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF4E342E)
                    )

                    Button(
                        onClick = {
                            ReminderNotificationHelper.playAlarmSound(context, isConfirmationChime = true)
                            onSendNudgeAlert(
                                "Medication reminder: The scheduled $unconfirmedTime dose ($unconfirmedName) for $patientName has not been confirmed."
                            )
                            try {
                                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$patientPhone"))
                                context.startActivity(dialIntent)
                            } catch (_: Exception) {
                            }
                        },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFC62828),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("call_family_member_button")
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Contact Patient",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }

        // Medication Adherence History & Trends Chart (Week | Month)
        item {
            CaregiverAdherenceHistoryChartCard(
                patientName = activePatient?.name ?: "Mr. Rao"
            )
        }

        // Firebase Cloud Messaging (FCM) Real-Time Push Notifications Card
        item {
            CaregiverFcmPushNotificationsCard(
                patientName = activePatient?.name ?: "Mr. Rao",
                patientPhone = activePatient?.phone ?: "+919848011223",
                nextMedicineName = unconfirmedMed?.name ?: "Metformin 500 mg",
                nextMedicineDosage = unconfirmedMed?.dosage ?: "1 tablet",
                nextMedicineTime = unconfirmedMed?.scheduledTime ?: "8:00 PM"
            )
        }

        // Recent Activity Section (Matches Screen 3: "8:00 AM – Medicine confirmed", "1:00 PM – Medicine confirmed", "8:30 PM – Alert sent")
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Activity",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "Live Sync →",
                    style = MaterialTheme.typography.labelLarge,
                    color = MedTealDark,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        val displayLogs = if (doseLogs.isNotEmpty()) {
            doseLogs.take(6)
        } else {
            com.example.data.model.MedMateDemoData.defaultDoseLogs()
        }

        items(displayLogs, key = { it.id.ifBlank { it.scheduledTime + it.medicineName } }) { log ->
            val isAlert = log.actionStatus == "missed"
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = if (isAlert) Icons.Default.Error else Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (isAlert) MedAlertRed else MedTakenGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (log.notes.isNotBlank()) {
                                log.notes
                            } else if (isAlert) {
                                "${log.scheduledTime} – Alert sent (${log.medicineName})"
                            } else {
                                "${log.scheduledTime} – Medicine confirmed (${log.medicineName})"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${log.patientName} • ${log.medicineName}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

private data class AdherenceTrendPoint(
    val label: String,
    val primaryPct: Int,
    val secondaryPct: Int,
    val detailText: String
)

/**
 * Interactive Caregiver 'History' Adherence Chart visualizing medication adherence trends
 * over the past Week (Mon–Sun) and Month (Week 1–Week 4) with grouped bars and trend line.
 */
@Composable
private fun CaregiverAdherenceHistoryChartCard(
    patientName: String
) {
    var selectedRange by remember { mutableStateOf("Week") }
    var selectedPointIndex by remember { mutableIntStateOf(1) }

    val weeklyPoints = remember {
        listOf(
            AdherenceTrendPoint("Mon", 86, 100, "Mon: 6/7 doses confirmed on time (86%)"),
            AdherenceTrendPoint("Tue", 100, 95, "Tue: 7/7 doses confirmed on time (100%)"),
            AdherenceTrendPoint("Wed", 86, 90, "Wed: 6/7 doses confirmed • 1 evening reminder sent (86%)"),
            AdherenceTrendPoint("Thu", 100, 100, "Thu: All scheduled morning, afternoon & night doses taken (100%)"),
            AdherenceTrendPoint("Fri", 92, 86, "Fri: 92% adherence • Metformin confirmed 15m after lunch"),
            AdherenceTrendPoint("Sat", 100, 100, "Sat: 100% adherence across BP & Diabetes regimen"),
            AdherenceTrendPoint("Sun", 75, 92, "Sun: 3 of 4 confirmed today (75%) • 8:00 PM pending")
        )
    }

    val monthlyPoints = remember {
        listOf(
            AdherenceTrendPoint("Week 1", 89, 92, "Week 1 (Oct 6–12): 89% average adherence (25/28 doses)"),
            AdherenceTrendPoint("Week 2", 93, 96, "Week 2 (Oct 13–19): 93% average adherence (26/28 doses)"),
            AdherenceTrendPoint("Week 3", 96, 94, "Week 3 (Oct 20–26): 96% average adherence (27/28 doses)"),
            AdherenceTrendPoint("Week 4", 91, 98, "Week 4 (Oct 27–Nov 2): 91% average adherence (25.5/28 doses)")
        )
    }

    val activePoints = if (selectedRange == "Week") weeklyPoints else monthlyPoints
    val safeIndex = selectedPointIndex.coerceIn(0, activePoints.lastIndex)
    val selectedPoint = activePoints[safeIndex]
    val avgAdherence = activePoints.map { it.primaryPct }.average().toInt()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .testTag("caregiver_history_chart_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.BarChart,
                        contentDescription = null,
                        tint = MedTealPrimary
                    )
                    Column {
                        Text(
                            text = "Adherence History Trend",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "$patientName • Avg $avgAdherence% ($selectedRange)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Segmented Week | Month Toggle
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFFEAF4F2)
                ) {
                    Row(modifier = Modifier.padding(3.dp)) {
                        listOf("Week", "Month").forEach { range ->
                            val isSelected = selectedRange == range
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(if (isSelected) Color(0xFF0A5C52) else Color.Transparent)
                                    .clickable {
                                        selectedRange = range
                                        selectedPointIndex = 0
                                    }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                                    .testTag("caregiver_chart_range_$range")
                            ) {
                                Text(
                                    text = range,
                                    color = if (isSelected) Color.White else MedTealDark,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }
            }

            // Legend Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(MedNavyBlue))
                    Text(text = patientName, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(MedSaffron))
                    Text(text = "Morning/Evening Target", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(MedTakenGreen))
                    Text(text = "Trend Line", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
            }

            // Grouped Bar + Trend Line Canvas Chart
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(175.dp)
                    .background(Color(0xFFF8FBFB), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 14.dp)
                    .testTag("caregiver_adherence_canvas")
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val count = activePoints.size.coerceAtLeast(1)
                    val slotWidth = size.width / count
                    val maxBarHeight = size.height * 0.82f
                    val baseLineY = size.height * 0.90f

                    // Subtle horizontal grid lines (50%, 75%, 100%)
                    listOf(0.25f, 0.55f, 0.90f).forEach { frac ->
                        drawLine(
                            color = Color(0xFFDCE7E5),
                            start = Offset(0f, size.height * frac),
                            end = Offset(size.width, size.height * frac),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    val trendPath = Path()

                    activePoints.forEachIndexed { idx, pt ->
                        val centerX = slotWidth * idx + slotWidth / 2f
                        val barW = (slotWidth * 0.24f).coerceAtMost(18.dp.toPx())

                        val h1 = (pt.primaryPct / 100f) * maxBarHeight
                        val h2 = (pt.secondaryPct / 100f) * maxBarHeight

                        // Primary patient adherence bar (Deep Navy / Teal highlight when selected)
                        drawRoundRect(
                            color = if (idx == safeIndex) MedTealPrimary else MedNavyBlue,
                            topLeft = Offset(centerX - barW - 2.dp.toPx(), baseLineY - h1),
                            size = Size(barW, h1),
                            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                        )

                        // Secondary comparison bar (Warm Saffron)
                        drawRoundRect(
                            color = MedSaffron,
                            topLeft = Offset(centerX + 2.dp.toPx(), baseLineY - h2),
                            size = Size(barW, h2),
                            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                        )

                        val trendY = baseLineY - h1
                        if (idx == 0) {
                            trendPath.moveTo(centerX, trendY)
                        } else {
                            trendPath.lineTo(centerX, trendY)
                        }
                    }

                    // Overlay smooth emerald trend line
                    drawPath(
                        path = trendPath,
                        color = MedTakenGreen,
                        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                    )

                    activePoints.forEachIndexed { idx, pt ->
                        val centerX = slotWidth * idx + slotWidth / 2f
                        val h1 = (pt.primaryPct / 100f) * maxBarHeight
                        drawCircle(
                            color = Color.White,
                            radius = 5.dp.toPx(),
                            center = Offset(centerX, baseLineY - h1)
                        )
                        drawCircle(
                            color = MedTakenGreen,
                            radius = 3.5.dp.toPx(),
                            center = Offset(centerX, baseLineY - h1)
                        )
                    }
                }
            }

            // Interactive X-Axis Labels (Tap a day/week to inspect adherence details)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                activePoints.forEachIndexed { idx, pt ->
                    val isSelected = idx == safeIndex
                    Surface(
                        onClick = { selectedPointIndex = idx },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) Color(0xFFD9F2EE) else Color.Transparent
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "${pt.primaryPct}%",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isSelected) MedTealDark else MedNavyBlue
                            )
                            Text(
                                text = pt.label,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                color = if (isSelected) MedTealDark else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Selected Point Callout Pill
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFEAF6F4),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = selectedPoint.detailText,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MedTealDark,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }
    }
}

/**
 * Real-time Firebase Cloud Messaging (FCM) card in the Caregiver Dashboard showing:
 * - Active FCM topic subscriptions (`medimate_patient_reminders` & `medimate_caregiver_alerts`)
 * - Device FCM registration token status
 * - Instant push dispatchers to test Patient Medicine Reminder and Caregiver Missed-Dose Alert
 * - Live incoming FCM Push Event feed
 */
@Composable
private fun CaregiverFcmPushNotificationsCard(
    patientName: String,
    patientPhone: String,
    nextMedicineName: String,
    nextMedicineDosage: String,
    nextMedicineTime: String
) {
    val context = LocalContext.current
    val fcmToken by MediMateFcmManager.fcmTokenFlow.collectAsStateWithLifecycle()
    val subscribedTopics by MediMateFcmManager.subscribedTopicsFlow.collectAsStateWithLifecycle()
    val pushHistory by MediMateFcmManager.pushHistoryFlow.collectAsStateWithLifecycle()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .testTag("caregiver_fcm_push_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = MedTealPrimary
                    )
                    Column {
                        Text(
                            text = "Firebase Cloud Messaging (FCM)",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Real-time Patient Reminders & Caregiver Alerts",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFFDFF5E6)
                ) {
                    Text(
                        text = "FCM Active",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MedTakenGreen,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF3F8F7),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Subscribed Topics: ${subscribedTopics.joinToString(", ")}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MedTealDark
                    )
                    Text(
                        text = "Registration Token: ${fcmToken.take(28)}…",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        MediMateFcmManager.sendPatientMedicineReminderPush(
                            context = context,
                            patientName = patientName,
                            medicineName = nextMedicineName,
                            dosage = nextMedicineDosage,
                            scheduledTime = nextMedicineTime
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MedTealPrimary,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("fcm_send_patient_reminder_btn")
                ) {
                    Text(
                        text = "Push Patient Reminder",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                Button(
                    onClick = {
                        MediMateFcmManager.sendCaregiverMissedDoseAlertPush(
                            context = context,
                            patientName = patientName,
                            medicineName = nextMedicineName,
                            dosage = nextMedicineDosage,
                            scheduledTime = nextMedicineTime,
                            patientPhone = patientPhone
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MedAlertRed,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("fcm_send_caregiver_alert_btn")
                ) {
                    Text(
                        text = "Push Missed Alert",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            pushHistory.take(2).forEach { push ->
                val isMissedAlert = push.type == MediMateFcmManager.TYPE_MISSED_DOSE_ALERT
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (isMissedAlert) Color(0xFFFDECEB) else Color(0xFFEDF8F5),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = push.title,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isMissedAlert) Color(0xFFB71C1C) else MedTealDark
                            )
                            Text(
                                text = push.timestampLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = push.body,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

