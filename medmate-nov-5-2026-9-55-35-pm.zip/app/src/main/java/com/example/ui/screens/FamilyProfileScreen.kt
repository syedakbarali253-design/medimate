package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FamilyMember
import com.example.data.model.Medicine
import com.example.data.model.UserProfile
import com.example.ui.theme.MedAlertRed
import com.example.ui.theme.MedAmberWarning
import com.example.ui.theme.MedNavyDark
import com.example.ui.theme.MedSaffron
import com.example.ui.theme.MedTakenGreen
import com.example.service.MedicineAlarmScheduler
import com.example.ui.theme.MedTealContainer
import com.example.ui.theme.MedTealDark
import com.example.ui.theme.MedTealPrimary
import com.example.util.ReminderNotificationHelper

/**
 * Screen 4 ("History & Reminders" + "Accessibility & Profile Settings") from
 * MediMate_Elder_Care_App_Dashboard__1__ccc801df.png:
 * - Deep Teal Header ("History & Reminders")
 * - Segmented Period Selector: Week | Month | Custom
 * - Week Calendar Strip: Mon 27 .. Thu 30 (highlighted dark teal circle) .. Sun 2 + Legend (Taken / Missed / Unconfirmed)
 * - Medicine Summary: Amlodipine 5 mg (7 / 7, 100%), Metformin 500 mg (6 / 7, 86%), Vitamin D (7 / 7, 100%)
 * - Voice Reminders Toggle Switch & Notifications Toggle Switch + Configurable Grace Period
 * - Info Banner: "ⓘ MediMate keeps your family informed about your medicine schedule."
 * - Senior Accessibility Settings (Large Text, High Contrast, English/Hindi/Telugu) & Family Circle QR Link
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FamilyProfileScreen(
    userProfile: UserProfile?,
    familyMembers: List<FamilyMember>,
    medicines: List<Medicine> = emptyList(),
    selectedLanguage: String = "English",
    onLanguageChange: (String) -> Unit = {},
    largeTextMode: Boolean = false,
    onLargeTextModeChange: (Boolean) -> Unit = {},
    highContrastMode: Boolean = false,
    onHighContrastModeChange: (Boolean) -> Unit = {},
    onSaveProfile: (String, Long, String, String, String, String, String, String) -> Unit,
    onAddFamilyMember: (String, String, Long, String, String, String, String, String, String) -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current

    var name by remember { mutableStateOf(userProfile?.name ?: "Mr. Rao") }
    var ageStr by remember { mutableStateOf((userProfile?.age ?: 72L).toString()) }
    var bloodGroup by remember { mutableStateOf(userProfile?.bloodGroup ?: "B+") }
    var allergies by remember { mutableStateOf(userProfile?.allergies ?: "Sulfa drugs") }
    var language by remember { mutableStateOf(userProfile?.language ?: selectedLanguage) }
    var accountMode by remember { mutableStateOf(userProfile?.accountMode ?: "both") }
    var inviteCode by remember { mutableStateOf(userProfile?.inviteCode ?: "MM-RAO7") }
    var phone by remember { mutableStateOf(userProfile?.phone ?: "+91 98490 22310") }

    var selectedPeriod by remember { mutableStateOf("Week") }
    var selectedDayIndex by remember { mutableIntStateOf(3) } // Thu 30 highlighted per mockup
    var voiceRemindersEnabled by remember { mutableStateOf(true) }
    var notificationsEnabled by remember { mutableStateOf(true) }
    var reminderGraceMinutes by remember { mutableIntStateOf(30) }
    var showLinkDialog by remember { mutableStateOf(false) }

    LaunchedEffect(userProfile) {
        if (userProfile != null) {
            name = userProfile.name
            ageStr = userProfile.age.toString()
            bloodGroup = userProfile.bloodGroup
            allergies = userProfile.allergies
            language = userProfile.language
            accountMode = userProfile.accountMode
            inviteCode = userProfile.inviteCode
            phone = userProfile.phone
        }
    }

    val weekDays = listOf(
        "Mon" to "27",
        "Tue" to "28",
        "Wed" to "29",
        "Thu" to "30",
        "Fri" to "31",
        "Sat" to "1",
        "Sun" to "2"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("family_profile_list"),
        contentPadding = PaddingValues(bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Deep Teal Top Bar matching Screen 4 ("History & Reminders")
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0A5C52))
                    .padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "History & Reminders",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Adherence log, voice alerts & senior settings",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                    OutlinedButton(
                        onClick = onSignOut,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
                        modifier = Modifier.testTag("sign_out_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Sign Out",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sign Out", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Screen 4 Card: Segmented Period Selector + Calendar Strip + Medicine Summary
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Week | Month | Custom Pill Selector
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(0xFFF0F4F3),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(4.dp)
                        ) {
                            listOf("Week", "Month", "Custom").forEach { period ->
                                val isSelected = selectedPeriod == period
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(50))
                                        .background(if (isSelected) Color(0xFF0A5C52) else Color.Transparent)
                                        .clickable { selectedPeriod = period }
                                        .padding(vertical = 10.dp)
                                        .testTag("history_period_$period"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = period,
                                        color = if (isSelected) Color.White else MedNavyDark,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                }
                            }
                        }
                    }

                    // Date Range Header (< Oct 27 – Nov 2, 2025 >)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Previous Week",
                            tint = MedNavyDark,
                            modifier = Modifier
                                .size(28.dp)
                                .clickable {
                                    selectedDayIndex = (selectedDayIndex - 1).coerceAtLeast(0)
                                }
                        )
                        Text(
                            text = when (selectedPeriod) {
                                "Month" -> "October – November 2025"
                                "Custom" -> "Last 14 Days Adherence"
                                else -> "Oct 27 – Nov 2, 2025"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MedNavyDark
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Next Week",
                            tint = MedNavyDark,
                            modifier = Modifier
                                .size(28.dp)
                                .clickable {
                                    selectedDayIndex = (selectedDayIndex + 1).coerceAtMost(6)
                                }
                        )
                    }

                    // Week Calendar Strip (Mon 27 .. Thu 30 highlighted .. Sun 2)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        weekDays.forEachIndexed { idx, (dayLabel, dateNum) ->
                            val isSelected = idx == selectedDayIndex
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.clickable { selectedDayIndex = idx }
                            ) {
                                Text(
                                    text = dayLabel,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) Color(0xFF0A5C52) else Color.Transparent),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = dateNum,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isSelected) Color.White else MedNavyDark
                                    )
                                }
                            }
                        }
                    }

                    // Legend: Taken | Missed | Unconfirmed
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LegendDot(color = MedTakenGreen, label = "Taken")
                        Spacer(modifier = Modifier.width(16.dp))
                        LegendDot(color = Color(0xFFE65100), label = "Missed")
                        Spacer(modifier = Modifier.width(16.dp))
                        LegendDot(color = Color(0xFFB0BEC5), label = "Unconfirmed")
                    }

                    HorizontalDivider(color = Color(0xFFE5ECEB))

                    // Medicine Summary section matching Screen 4
                    Text(
                        text = "Medicine Summary",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MedNavyDark
                    )

                    val summaryItems = listOf(
                        Triple("Amlodipine 5 mg", "7 / 7", 100),
                        Triple("Metformin 500 mg", "6 / 7", 86),
                        Triple("Vitamin D", "7 / 7", 100)
                    )

                    summaryItems.forEachIndexed { idx, (medName, ratio, pct) ->
                        val isPerfect = pct >= 95
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color(0xFFF7FAFA),
                            border = BorderStroke(1.dp, Color(0xFFE5ECEB)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    TwoToneCapsuleIcon(index = idx)
                                    Text(
                                        text = medName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MedNavyDark
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(
                                        text = ratio,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MedNavyDark
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = if (isPerfect) Color(0xFFDFF5E6) else Color(0xFFFFF0D6)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isPerfect) MedTakenGreen else MedAmberWarning)
                                            )
                                            Text(
                                                text = "$pct%",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = if (isPerfect) MedTakenGreen else Color(0xFFB25E00)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Screen 4 Card: Voice Reminders + Notifications + Info Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Voice Reminders Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = Color(0xFF0A5C52),
                                modifier = Modifier.size(26.dp)
                            )
                            Column {
                                Text(
                                    text = "Voice Reminders",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "Spoken alerts in $selectedLanguage",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = voiceRemindersEnabled,
                            onCheckedChange = { enabled ->
                                voiceRemindersEnabled = enabled
                                if (enabled) {
                                    ReminderNotificationHelper.speakMedicineReminder(
                                        context = context,
                                        language = selectedLanguage,
                                        medicineName = "Metformin 500 mg"
                                    )
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF0A8770)
                            ),
                            modifier = Modifier.testTag("voice_reminders_switch")
                        )
                    }

                    HorizontalDivider(color = Color(0xFFE5ECEB))

                    // Notifications Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = null,
                                tint = Color(0xFF0A5C52),
                                modifier = Modifier.size(26.dp)
                            )
                            Column {
                                Text(
                                    text = "Notifications (AlarmManager Service)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "Scheduled local alarms & audible chime",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = notificationsEnabled,
                            onCheckedChange = { enabled ->
                                notificationsEnabled = enabled
                                if (enabled) {
                                    MedicineAlarmScheduler.scheduleAllDailyMedicineAlarms(
                                        context = context,
                                        medicines = medicines,
                                        language = selectedLanguage,
                                        gracePeriodMinutes = reminderGraceMinutes,
                                        voiceEnabled = voiceRemindersEnabled
                                    )
                                    ReminderNotificationHelper.playAlarmSound(context)
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF0A8770)
                            ),
                            modifier = Modifier.testTag("notifications_switch")
                        )
                    }

                    // Configurable Caregiver Alert Grace Period
                    Text(
                        text = "Caregiver Missed-Dose Alert Grace Window (AlarmManager Escalation):",
                        style = MaterialTheme.typography.labelLarge,
                        color = MedTealDark,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(15, 30, 45).forEach { mins ->
                                FilterChip(
                                    selected = reminderGraceMinutes == mins,
                                    onClick = {
                                        reminderGraceMinutes = mins
                                        MedicineAlarmScheduler.scheduleAllDailyMedicineAlarms(
                                            context = context,
                                            medicines = medicines,
                                            language = selectedLanguage,
                                            gracePeriodMinutes = mins,
                                            voiceEnabled = voiceRemindersEnabled
                                        )
                                    },
                                    label = { Text("$mins mins") }
                                )
                            }
                        }

                        TextButton(
                            onClick = {
                                val nextMed = medicines.firstOrNull { !it.takenToday } ?: medicines.firstOrNull()
                                MedicineAlarmScheduler.scheduleDelayReminder(
                                    context = context,
                                    medicineName = nextMed?.name ?: "Metformin 500 mg",
                                    dosage = nextMed?.dosage ?: "1 tablet",
                                    scheduledTime = nextMed?.scheduledTime ?: "1:00 PM",
                                    instructions = nextMed?.mealInstruction ?: "After Meals",
                                    patientName = name,
                                    language = selectedLanguage,
                                    delaySeconds = 2,
                                    isCaregiverEscalation = false,
                                    voiceEnabled = voiceRemindersEnabled,
                                    triggerImmediately = true
                                )
                            },
                            modifier = Modifier.testTag("test_alarm_service_btn")
                        ) {
                            Text("Test Alarm", fontWeight = FontWeight.Bold, color = MedTealPrimary)
                        }
                    }

                    // Info Banner matching Screen 4 bottom
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFFE3F2FD),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Color(0xFF1565C0),
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = "MediMate keeps your family informed about your medicine schedule.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF0D3B66),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Senior Accessibility & Multilingual Settings Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccessibilityNew,
                            contentDescription = null,
                            tint = MedTealPrimary
                        )
                        Text(
                            text = "Senior Accessibility & Spoken Language",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Text(
                        text = "Voice & UI Language (English / हिंदी / తెలుగు):",
                        style = MaterialTheme.typography.labelLarge
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "English" to "English",
                            "Hindi" to "हिंदी (Hindi)",
                            "Telugu" to "తెలుగు (Telugu)"
                        ).forEach { (langKey, langLabel) ->
                            FilterChip(
                                selected = selectedLanguage == langKey,
                                onClick = {
                                    language = langKey
                                    onLanguageChange(langKey)
                                    ReminderNotificationHelper.speakMedicineReminder(
                                        context = context,
                                        language = langKey,
                                        medicineName = "Metformin 500 mg"
                                    )
                                },
                                label = { Text(langLabel, fontWeight = FontWeight.Bold) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Large Senior Text Mode",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Increases button & label readability for elderly eyes",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = largeTextMode,
                            onCheckedChange = onLargeTextModeChange,
                            modifier = Modifier.testTag("large_text_switch")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "High-Contrast Card Borders",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Stronger status badges & high-visibility outlines",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = highContrastMode,
                            onCheckedChange = onHighContrastModeChange,
                            modifier = Modifier.testTag("high_contrast_switch")
                        )
                    }
                }
            }
        }

        // Family Invite Code & QR Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MedTealContainer.copy(alpha = 0.65f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    SimulatedQrBadge(
                        code = inviteCode,
                        modifier = Modifier.size(84.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Family Caregiver Link Code",
                            style = MaterialTheme.typography.labelLarge,
                            color = MedTealPrimary
                        )
                        Text(
                            text = inviteCode,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MedNavyDark
                        )
                        Text(
                            text = "Share this code or scan QR so Anita Rao or another caregiver can monitor doses securely.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { showLinkDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MedTealPrimary),
                            modifier = Modifier.testTag("link_family_member_btn")
                        ) {
                            Icon(Icons.Default.GroupAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Link Parent / Caregiver")
                        }
                    }
                }
            }
        }

        // Linked Family Members List
        item {
            Text(
                text = "Linked Family Members (${familyMembers.size})",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
        }

        items(familyMembers, key = { it.id.ifBlank { it.name } }) { member ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${member.name} • ${member.relation}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MedSaffron.copy(alpha = 0.16f)
                        ) {
                            Text(
                                text = "Code: ${member.inviteCode}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MedSaffron,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Text(
                        text = "Age: ${member.age} yrs • Blood Group: ${member.bloodGroup} • City: ${member.city}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Conditions: ${member.conditions}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        // Personal Profile & Role Selection Form
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = MedTealPrimary)
                        Text(
                            text = "Patient & Caregiver Profile",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "both" to "Both (Patient + Caregiver)",
                            "patient" to "Elderly Patient",
                            "caregiver" to "Family Caregiver"
                        ).forEach { (modeKey, modeLabel) ->
                            FilterChip(
                                selected = accountMode == modeKey,
                                onClick = { accountMode = modeKey },
                                label = { Text(modeLabel) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Full Name") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_name_input")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = ageStr,
                            onValueChange = { ageStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Age") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = bloodGroup,
                            onValueChange = { bloodGroup = it },
                            label = { Text("Blood Group") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = allergies,
                        onValueChange = { allergies = it },
                        label = { Text("Drug / Food Allergies") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            onSaveProfile(
                                name,
                                ageStr.toLongOrNull() ?: 72L,
                                bloodGroup,
                                allergies,
                                language,
                                accountMode,
                                inviteCode,
                                phone
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MedTealPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_profile_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Profile Preferences")
                    }
                }
            }
        }
    }

    if (showLinkDialog) {
        LinkFamilyMemberDialog(
            onDismiss = { showLinkDialog = false },
            onConfirm = { mName, mRel, mAge, mBlood, mAllergies, mCond, mCity, mPhone, mCode ->
                onAddFamilyMember(mName, mRel, mAge, mBlood, mAllergies, mCond, mCity, mPhone, mCode)
                showLinkDialog = false
            }
        )
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            color = MedNavyDark
        )
    }
}

@Composable
private fun SimulatedQrBadge(
    code: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        shadowElevation = 2.dp
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(8.dp)) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cells = 7
                val cellSize = size.width / cells
                val hash = code.hashCode()
                for (r in 0 until cells) {
                    for (c in 0 until cells) {
                        val isCorner = (r < 2 && c < 2) || (r < 2 && c >= cells - 2) || (r >= cells - 2 && c < 2)
                        val bit = ((hash shr ((r * cells + c) % 16)) and 1) == 1
                        if (isCorner || bit) {
                            drawRect(
                                color = MedNavyDark,
                                topLeft = Offset(c * cellSize, r * cellSize),
                                size = Size(cellSize * 0.85f, cellSize * 0.85f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LinkFamilyMemberDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, Long, String, String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var relation by remember { mutableStateOf("Mother (Amma)") }
    var ageStr by remember { mutableStateOf("68") }
    var bloodGroup by remember { mutableStateOf("O+") }
    var allergies by remember { mutableStateOf("None") }
    var conditions by remember { mutableStateOf("Hypertension, Type 2 Diabetes") }
    var city by remember { mutableStateOf("Hyderabad, TS") }
    var phone by remember { mutableStateOf("+91 98490 55112") }
    var inviteCode by remember { mutableStateOf("MM-AMMA") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.QrCode2, contentDescription = null, tint = MedTealPrimary)
                Text("Link Parent via Invite Code")
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = inviteCode,
                    onValueChange = { inviteCode = it },
                    label = { Text("Patient Invite / QR Code") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Parent Name (e.g. Lakshmi Rao)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("link_member_name_input")
                )
                OutlinedTextField(
                    value = relation,
                    onValueChange = { relation = it },
                    label = { Text("Relation (Mother, Father, Grandmother)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = ageStr,
                        onValueChange = { ageStr = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Age") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = bloodGroup,
                        onValueChange = { bloodGroup = it },
                        label = { Text("Blood Group") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = conditions,
                    onValueChange = { conditions = it },
                    label = { Text("Long-Term Conditions") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text("City") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(
                            name,
                            relation,
                            ageStr.toLongOrNull() ?: 68L,
                            bloodGroup,
                            allergies,
                            conditions,
                            city,
                            phone,
                            inviteCode
                        )
                    }
                },
                modifier = Modifier.testTag("confirm_link_member_btn")
            ) {
                Text("Link to Family")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
