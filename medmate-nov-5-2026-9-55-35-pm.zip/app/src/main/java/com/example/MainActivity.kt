package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Medication
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.AuthScreen
import com.example.auth.signOut
import com.example.data.model.BioscienceReport
import com.example.data.model.DoseLog
import com.example.data.model.FamilyMember
import com.example.data.model.MedMateDemoData
import com.example.data.model.Medicine
import com.example.data.model.ScannedPrescriptionMedicine
import com.example.data.repository.MedMateRepository
import com.example.service.MediMateFcmManager
import com.example.ui.screens.CaregiverDashboardScreen
import com.example.ui.screens.FamilyProfileScreen
import com.example.ui.screens.MyMedicinesScreen
import com.example.ui.screens.PatientTodayScreen
import com.example.ui.screens.RxBioLabScreen
import com.example.ui.theme.MedMateTheme
import com.example.ui.theme.MedTealContainer
import com.example.ui.theme.MedTealDark
import com.example.util.ReminderNotificationHelper
import com.example.util.configureAppCheck
import com.example.viewmodel.AiTaskState
import com.example.viewmodel.MedMateViewModel
import com.example.viewmodel.UiState
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI, ViewModels, or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            MedMateTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

/**
 * 5-Tab Bottom Navigation matching MediMate_Elder_Care_App_Dashboard__1__ccc801df.png:
 * Home | Medicines | History | Family | AI & Rx
 */
enum class MedMateTab(val route: String, val label: String) {
    HOME("home", "Home"),
    MEDICINES("medicines", "Medicines"),
    HISTORY("history", "History"),
    FAMILY("family", "Family"),
    AI_RX("settings", "AI & Rx")
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    var isDemoSession by rememberSaveable { mutableStateOf(false) }
    var selectedRole by rememberSaveable { mutableStateOf("patient") }

    if (user == null && !isDemoSession) {
        AuthScreen(
            onAuthSuccess = { role ->
                selectedRole = role
            },
            onEnterDemoMode = { role ->
                selectedRole = role
                isDemoSession = true
            }
        )
    } else if (user != null) {
        MedMateMainShell(
            currentUserId = user.uid,
            displayName = user.displayName,
            initialRole = selectedRole
        )
    } else {
        MedMateDemoShell(
            initialRole = selectedRole,
            onExitDemoMode = { isDemoSession = false }
        )
    }
}

@Composable
fun MedMateMainShell(
    currentUserId: String,
    displayName: String?,
    initialRole: String = "patient"
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    val viewModel: MedMateViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                MedMateViewModel(
                    repository = MedMateRepository(db),
                    currentUserId = currentUserId,
                    initialDisplayName = displayName
                )
            }
        }
    )

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        ReminderNotificationHelper.ensureChannel(context)
        MediMateFcmManager.initializeAndSubscribe(
            context = context,
            role = initialRole,
            familyInviteCode = "MM-RAO7"
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !ReminderNotificationHelper.hasNotificationPermission(context)
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    var currentTab by rememberSaveable {
        mutableStateOf(
            if (initialRole == "caregiver") MedMateTab.FAMILY else MedMateTab.HOME
        )
    }
    var selectedLanguage by rememberSaveable { mutableStateOf("English") }
    var largeTextMode by rememberSaveable { mutableStateOf(false) }
    var highContrastMode by rememberSaveable { mutableStateOf(false) }

    if (currentTab != MedMateTab.HOME) {
        BackHandler {
            currentTab = MedMateTab.HOME
        }
    }

    val profileState by viewModel.userProfileState.collectAsStateWithLifecycle()
    val familyState by viewModel.familyMembersState.collectAsStateWithLifecycle()
    val medicinesState by viewModel.medicinesState.collectAsStateWithLifecycle()
    val doseLogsState by viewModel.doseLogsState.collectAsStateWithLifecycle()
    val selectedMemberId by viewModel.selectedMemberId.collectAsStateWithLifecycle()
    val actionFeedback by viewModel.actionFeedback.collectAsStateWithLifecycle()
    val scannedState by viewModel.scannedMedicinesState.collectAsStateWithLifecycle()
    val bioscienceState by viewModel.bioscienceReportState.collectAsStateWithLifecycle()
    val quickGuideState by viewModel.quickHindiExplanationState.collectAsStateWithLifecycle()
    val aiAssistantState by viewModel.aiAssistantState.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(actionFeedback) {
        val msg = actionFeedback
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedback()
        }
    }

    val userProfile = (profileState as? UiState.Success)?.data
    val familyMembers = (familyState as? UiState.Success)?.data ?: emptyList()
    val medicines = (medicinesState as? UiState.Success)?.data ?: emptyList()
    val doseLogs = (doseLogsState as? UiState.Success)?.data ?: emptyList()

    val activeMember = familyMembers.find { it.id == selectedMemberId } ?: familyMembers.firstOrNull()
    val patientMeds = if (activeMember != null) {
        val filtered = medicines.filter { it.memberId == activeMember.id || it.patientName == activeMember.name }
        if (filtered.isNotEmpty()) filtered else medicines
    } else {
        medicines
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            MedMateBottomBar(
                currentTab = currentTab,
                onSelectTab = { currentTab = it }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (medicinesState is UiState.Loading && familyState is UiState.Loading) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            } else {
                when (currentTab) {
                    MedMateTab.HOME -> PatientTodayScreen(
                        familyMembers = familyMembers,
                        selectedMemberId = selectedMemberId,
                        onSelectMember = { viewModel.selectFamilyMember(it) },
                        medicines = medicines,
                        selectedLanguage = selectedLanguage,
                        onLanguageChange = { selectedLanguage = it },
                        isDemoMode = false,
                        quickGuideState = quickGuideState,
                        onRequestQuickGuide = { viewModel.generateQuickElderlyGuide(it) },
                        onDismissQuickGuide = { viewModel.dismissQuickGuide() },
                        onMarkDoseStatus = { med, status, note ->
                            viewModel.markDoseStatus(med, status, note)
                        },
                        onAddMedicine = { memberId, patientName, name, dosage, slot, time, meal, cond, mech ->
                            viewModel.addMedicine(memberId, patientName, name, dosage, slot, time, meal, cond, mech)
                        },
                        onSimulateMissedDoseAlert = { med ->
                            viewModel.markDoseStatus(med, "missed", "8:30 PM – Caregiver alert sent to Anita Rao")
                        }
                    )

                    MedMateTab.MEDICINES -> MyMedicinesScreen(
                        patientName = activeMember?.name ?: "Mr. Rao",
                        activeMemberId = activeMember?.id ?: "default_member",
                        medicines = patientMeds,
                        selectedLanguage = selectedLanguage,
                        onAddMedicine = { memberId, patientName, name, dosage, slot, time, meal, cond, mech ->
                            viewModel.addMedicine(memberId, patientName, name, dosage, slot, time, meal, cond, mech)
                        },
                        onDeleteMedicine = { viewModel.deleteMedicine(it) }
                    )

                    MedMateTab.HISTORY -> FamilyProfileScreen(
                        userProfile = userProfile,
                        familyMembers = familyMembers,
                        medicines = patientMeds,
                        selectedLanguage = selectedLanguage,
                        onLanguageChange = { selectedLanguage = it },
                        largeTextMode = largeTextMode,
                        onLargeTextModeChange = { largeTextMode = it },
                        highContrastMode = highContrastMode,
                        onHighContrastModeChange = { highContrastMode = it },
                        onSaveProfile = { name, age, bg, allg, lang, mode, code, ph ->
                            viewModel.updateProfile(name, age, bg, allg, lang, mode, code, ph)
                        },
                        onAddFamilyMember = { mName, mRel, mAge, mBg, mAllg, mCond, mCity, mPh, mCode ->
                            viewModel.addFamilyMember(mName, mRel, mAge, mBg, mAllg, mCond, mCity, mPh, mCode)
                        },
                        onSignOut = {
                            signOut(
                                context = context,
                                credentialManager = credentialManager,
                                onSignOutComplete = {},
                                scope = scope
                            )
                        }
                    )

                    MedMateTab.FAMILY -> CaregiverDashboardScreen(
                        userProfile = userProfile,
                        familyMembers = familyMembers,
                        medicines = medicines,
                        doseLogs = doseLogs,
                        onSelectPatientForTodayView = { memberId ->
                            viewModel.selectFamilyMember(memberId)
                            currentTab = MedMateTab.HOME
                        },
                        onSendNudgeAlert = { feedbackMsg ->
                            ReminderNotificationHelper.sendDoseReminderNotification(
                                context = context,
                                title = "MediMate Family Care Alert",
                                body = feedbackMsg
                            )
                        }
                    )

                    MedMateTab.AI_RX -> RxBioLabScreen(
                        familyMembers = familyMembers,
                        selectedMemberId = selectedMemberId,
                        medicines = patientMeds,
                        selectedLanguage = selectedLanguage,
                        scannedState = scannedState,
                        bioscienceState = bioscienceState,
                        aiAssistantState = aiAssistantState,
                        onAskAiAssistant = { question, lang ->
                            viewModel.askMediMateAiAssistant(question, lang, patientMeds)
                        },
                        onScanPrescription = { text, bmp ->
                            viewModel.scanPrescriptionWithAi(text, bmp)
                        },
                        onImportScannedMedicine = { scanned ->
                            viewModel.addMedicine(
                                memberId = activeMember?.id ?: "default_member",
                                patientName = activeMember?.name ?: "Mr. Rao",
                                name = scanned.name,
                                dosage = scanned.dosage,
                                timeSlot = scanned.timeSlot,
                                scheduledTime = scanned.scheduledTime,
                                mealInstruction = scanned.mealInstruction,
                                conditionTag = scanned.conditionTag,
                                bioscienceMechanism = scanned.bioscienceMechanism
                            )
                        },
                        onRunDeepBioscienceAnalysis = {
                            viewModel.runDeepBioscienceAnalysis(patientMeds, activeMember)
                        }
                    )
                }
            }
        }
    }
}

/**
 * Interactive Demo Mode Shell using fictional Mr. Rao & Anita Rao dataset
 * (`[DEMO MODE — SIMULATED NOTIFICATIONS]`) so reviewers can test taking medicines,
 * triggering missed-dose alerts, switching between Patient & Caregiver views, and hearing
 * English/Hindi/Telugu voice reminders immediately.
 */
@Composable
fun MedMateDemoShell(
    initialRole: String,
    onExitDemoMode: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var currentTab by rememberSaveable {
        mutableStateOf(
            if (initialRole == "caregiver") MedMateTab.FAMILY else MedMateTab.HOME
        )
    }
    var selectedLanguage by rememberSaveable { mutableStateOf("English") }
    var largeTextMode by rememberSaveable { mutableStateOf(false) }
    var highContrastMode by rememberSaveable { mutableStateOf(false) }

    var demoProfile by remember {
        mutableStateOf(MedMateDemoData.defaultProfile(initialRole))
    }
    val demoMembers = remember {
        mutableStateListOf<FamilyMember>().apply {
            addAll(MedMateDemoData.defaultFamilyMembers())
        }
    }
    val demoMedicines = remember {
        mutableStateListOf<Medicine>().apply {
            addAll(MedMateDemoData.defaultMedicines())
        }
    }
    val demoLogs = remember {
        mutableStateListOf<DoseLog>().apply {
            addAll(MedMateDemoData.defaultDoseLogs())
        }
    }
    var selectedMemberId by remember { mutableStateOf<String?>("demo_mr_rao") }
    var quickGuideState by remember { mutableStateOf<AiTaskState<String>>(AiTaskState.Idle) }
    var aiAssistantState by remember { mutableStateOf<AiTaskState<String>>(AiTaskState.Idle) }
    var scannedState by remember {
        mutableStateOf<AiTaskState<List<ScannedPrescriptionMedicine>>>(AiTaskState.Idle)
    }
    var bioscienceState by remember {
        mutableStateOf<AiTaskState<BioscienceReport>>(AiTaskState.Idle)
    }

    LaunchedEffect(Unit) {
        MediMateFcmManager.initializeAndSubscribe(
            context = context,
            role = initialRole,
            familyInviteCode = "MM-RAO7"
        )
    }

    if (currentTab != MedMateTab.HOME) {
        BackHandler {
            currentTab = MedMateTab.HOME
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            MedMateBottomBar(
                currentTab = currentTab,
                onSelectTab = { currentTab = it }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                MedMateTab.HOME -> PatientTodayScreen(
                    familyMembers = demoMembers,
                    selectedMemberId = selectedMemberId,
                    onSelectMember = { selectedMemberId = it },
                    medicines = demoMedicines,
                    selectedLanguage = selectedLanguage,
                    onLanguageChange = { selectedLanguage = it },
                    isDemoMode = true,
                    quickGuideState = quickGuideState,
                    onRequestQuickGuide = { med ->
                        quickGuideState = AiTaskState.Success(
                            "Namaste ${med.patientName}! ${med.name} (${med.dosage}) is scheduled for ${med.scheduledTime} (${med.mealInstruction}). Please take it with a full glass of water as prescribed by your doctor. (Medical Disclaimer: Follow your doctor's instructions.)"
                        )
                    },
                    onDismissQuickGuide = { quickGuideState = AiTaskState.Idle },
                    onMarkDoseStatus = { med, status, note ->
                        val idx = demoMedicines.indexOfFirst { it.id == med.id }
                        if (idx >= 0) {
                            demoMedicines[idx] = med.copy(
                                takenToday = status == "taken",
                                todayStatus = status
                            )
                        }
                        demoLogs.add(
                            0,
                            DoseLog(
                                id = "log_${System.currentTimeMillis()}",
                                userId = "demo_user",
                                memberId = med.memberId,
                                patientName = med.patientName,
                                medicineId = med.id,
                                medicineName = med.name,
                                dosage = med.dosage,
                                scheduledTime = med.scheduledTime,
                                actionStatus = status,
                                notes = note.ifBlank { "${med.scheduledTime} – Medicine $status" },
                                createdAt = Timestamp.now()
                            )
                        )
                        scope.launch {
                            snackbarHostState.showSnackbar(
                                "[DEMO MODE] Updated ${med.name} status to ${status.uppercase()}"
                            )
                        }
                    },
                    onAddMedicine = { memberId, patientName, name, dosage, slot, time, meal, cond, mech ->
                        demoMedicines.add(
                            Medicine(
                                id = "med_${System.currentTimeMillis()}",
                                userId = "demo_user",
                                memberId = memberId,
                                patientName = patientName,
                                name = name,
                                dosage = dosage,
                                timeSlot = slot,
                                scheduledTime = time,
                                mealInstruction = meal,
                                conditionTag = cond,
                                bioscienceMechanism = mech,
                                stockRemaining = 30L,
                                takenToday = false,
                                todayStatus = "pending",
                                createdAt = Timestamp.now()
                            )
                        )
                        scope.launch {
                            snackbarHostState.showSnackbar("Added $name to $patientName's schedule")
                        }
                    },
                    onSimulateMissedDoseAlert = { med ->
                        val idx = demoMedicines.indexOfFirst { it.id == med.id }
                        if (idx >= 0) {
                            demoMedicines[idx] = med.copy(
                                takenToday = false,
                                todayStatus = "missed"
                            )
                        }
                        MediMateFcmManager.sendCaregiverMissedDoseAlertPush(
                            context = context,
                            patientName = med.patientName.ifBlank { "Mr. Rao" },
                            medicineName = med.name,
                            dosage = med.dosage,
                            scheduledTime = med.scheduledTime,
                            language = selectedLanguage
                        )
                        demoLogs.add(
                            0,
                            DoseLog(
                                id = "log_missed_${System.currentTimeMillis()}",
                                userId = "demo_user",
                                memberId = med.memberId,
                                patientName = med.patientName,
                                medicineId = med.id,
                                medicineName = med.name,
                                dosage = med.dosage,
                                scheduledTime = med.scheduledTime,
                                actionStatus = "missed",
                                notes = "8:30 PM – FCM Missed-dose push sent to Anita Rao (${med.name} not confirmed)",
                                createdAt = Timestamp.now()
                            )
                        )
                        scope.launch {
                            snackbarHostState.showSnackbar(
                                "[DEMO MODE — FCM PUSH] Missed-dose push notification sent to Anita Rao!"
                            )
                        }
                    }
                )

                MedMateTab.MEDICINES -> MyMedicinesScreen(
                    patientName = "Mr. Rao",
                    activeMemberId = "demo_mr_rao",
                    medicines = demoMedicines,
                    selectedLanguage = selectedLanguage,
                    onAddMedicine = { memberId, patientName, name, dosage, slot, time, meal, cond, mech ->
                        demoMedicines.add(
                            Medicine(
                                id = "med_${System.currentTimeMillis()}",
                                userId = "demo_user",
                                memberId = memberId,
                                patientName = patientName,
                                name = name,
                                dosage = dosage,
                                timeSlot = slot,
                                scheduledTime = time,
                                mealInstruction = meal,
                                conditionTag = cond,
                                bioscienceMechanism = mech,
                                stockRemaining = 30L,
                                takenToday = false,
                                todayStatus = "pending",
                                createdAt = Timestamp.now()
                            )
                        )
                    },
                    onDeleteMedicine = { id ->
                        demoMedicines.removeAll { it.id == id }
                    }
                )

                MedMateTab.HISTORY -> FamilyProfileScreen(
                    userProfile = demoProfile,
                    familyMembers = demoMembers,
                    medicines = demoMedicines,
                    selectedLanguage = selectedLanguage,
                    onLanguageChange = { selectedLanguage = it },
                    largeTextMode = largeTextMode,
                    onLargeTextModeChange = { largeTextMode = it },
                    highContrastMode = highContrastMode,
                    onHighContrastModeChange = { highContrastMode = it },
                    onSaveProfile = { name, age, bg, allg, lang, mode, code, ph ->
                        demoProfile = demoProfile.copy(
                            name = name,
                            age = age,
                            bloodGroup = bg,
                            allergies = allg,
                            language = lang,
                            accountMode = mode,
                            inviteCode = code,
                            phone = ph
                        )
                        scope.launch {
                            snackbarHostState.showSnackbar("Saved profile preferences")
                        }
                    },
                    onAddFamilyMember = { mName, mRel, mAge, mBg, mAllg, mCond, mCity, mPh, mCode ->
                        demoMembers.add(
                            FamilyMember(
                                id = "member_${System.currentTimeMillis()}",
                                userId = "demo_user",
                                name = mName,
                                relation = mRel,
                                age = mAge,
                                bloodGroup = mBg,
                                allergies = mAllg,
                                conditions = mCond,
                                city = mCity,
                                phone = mPh,
                                inviteCode = mCode,
                                createdAt = Timestamp.now()
                            )
                        )
                    },
                    onSignOut = onExitDemoMode
                )

                MedMateTab.FAMILY -> CaregiverDashboardScreen(
                    userProfile = demoProfile,
                    familyMembers = demoMembers,
                    medicines = demoMedicines,
                    doseLogs = demoLogs,
                    onSelectPatientForTodayView = { memberId ->
                        selectedMemberId = memberId
                        currentTab = MedMateTab.HOME
                    },
                    onSendNudgeAlert = { feedbackMsg ->
                        ReminderNotificationHelper.sendDoseReminderNotification(
                            context = context,
                            title = "[DEMO] MediMate Caregiver Alert",
                            body = feedbackMsg
                        )
                        scope.launch {
                            snackbarHostState.showSnackbar(feedbackMsg)
                        }
                    }
                )

                MedMateTab.AI_RX -> RxBioLabScreen(
                    familyMembers = demoMembers,
                    selectedMemberId = selectedMemberId,
                    medicines = demoMedicines,
                    selectedLanguage = selectedLanguage,
                    scannedState = scannedState,
                    bioscienceState = bioscienceState,
                    aiAssistantState = aiAssistantState,
                    onAskAiAssistant = { question, lang ->
                        val responseText = when (lang) {
                            "Hindi" -> "नमस्ते! श्री राव की निर्धारित दवा अनुसूची में सुबह 8:00 बजे Amlodipine 5 mg, दोपहर 1:00 बजे Metformin 500 mg और रात 8:00 बजे Vitamin D शामिल हैं। यदि कोई खुराक छूट गई है, तो कृपया कभी भी खुराक दोगुनी न करें और अपने डॉक्टर से परामर्श करें। (चिकित्सा अस्वीकरण: यह केवल अनुस्मारक सहायता के लिए है।)"
                            "Telugu" -> "నమస్కారం! శ్రీ రావు గారి మందుల షెడ్యూల్‌లో ఉదయం 8:00 గంటలకు Amlodipine 5 mg, మధ్యాహ్నం 1:00 గంటలకు Metformin 500 mg, మరియు రాత్రి 8:00 గంటలకు Vitamin D ఉన్నాయి. ఒకవేళ మందు వేసుకోవడం మర్చిపోతే, మోతాదును రెట్టింపు చేయవద్దు; డాక్టర్ సలహా తీసుకోండి."
                            else -> "Hello! For your question (\"$question\"): Mr. Rao's schedule includes Amlodipine 5 mg at 8:00 AM (Taken), Metformin 500 mg at 1:00 PM (Due now), Vitamin D at 8:00 PM (Upcoming), and Calcium 600 mg at 9:00 PM. Safety Note: Never double a missed dose or alter dosage without consulting the prescribing physician."
                        }
                        aiAssistantState = AiTaskState.Success(responseText)
                    },
                    onScanPrescription = { _, _ ->
                        scannedState = AiTaskState.Success(
                            listOf(
                                ScannedPrescriptionMedicine(
                                    name = "Amlodipine 5 mg",
                                    dosage = "1 tablet • Once daily",
                                    timeSlot = "Morning",
                                    scheduledTime = "8:00 AM",
                                    mealInstruction = "After Breakfast",
                                    conditionTag = "Hypertension (BP)",
                                    bioscienceMechanism = "Dihydropyridine L-type calcium channel blocker."
                                ),
                                ScannedPrescriptionMedicine(
                                    name = "Metformin 500 mg",
                                    dosage = "1 tablet • Twice daily",
                                    timeSlot = "Afternoon",
                                    scheduledTime = "1:00 PM",
                                    mealInstruction = "After Lunch",
                                    conditionTag = "Type 2 Diabetes",
                                    bioscienceMechanism = "Hepatic AMPK activator; take with meals."
                                )
                            )
                        )
                    },
                    onImportScannedMedicine = { scanned ->
                        demoMedicines.add(
                            Medicine(
                                id = "med_scan_${System.currentTimeMillis()}",
                                userId = "demo_user",
                                memberId = "demo_mr_rao",
                                patientName = "Mr. Rao",
                                name = scanned.name,
                                dosage = scanned.dosage,
                                timeSlot = scanned.timeSlot,
                                scheduledTime = scanned.scheduledTime,
                                mealInstruction = scanned.mealInstruction,
                                conditionTag = scanned.conditionTag,
                                bioscienceMechanism = scanned.bioscienceMechanism,
                                stockRemaining = 30L,
                                takenToday = false,
                                todayStatus = "pending",
                                createdAt = Timestamp.now()
                            )
                        )
                        scope.launch {
                            snackbarHostState.showSnackbar("Confirmed & added ${scanned.name} to Mr. Rao's schedule")
                        }
                    },
                    onRunDeepBioscienceAnalysis = {
                        bioscienceState = AiTaskState.Success(
                            BioscienceReport(
                                clinicalSummary = "Mr. Rao's regimen combines a long-acting dihydropyridine calcium channel blocker (Amlodipine 5 mg) with biguanide glycemic therapy (Metformin 500 mg) and cholecalciferol/calcium bone support.",
                                pharmacokineticPathways = listOf(
                                    "Amlodipine: 35–50h terminal half-life via hepatic CYP3A4; provides 24-hour smooth blood pressure control.",
                                    "Metformin: Renal excretion via OCT2/MATE1 without hepatic metabolism; AMPK activation reduces hepatic gluconeogenesis."
                                ),
                                drugFoodInteractions = listOf(
                                    "Take Metformin 500 mg immediately after Indian meals (roti/rice/dal) to buffer GI side effects.",
                                    "Space Calcium 600 mg at 9:00 PM away from iron or thyroid supplements to prevent divalent cation chelation."
                                ),
                                chronoPharmacologyTip = "Morning Amlodipine blunts the post-awakening blood pressure surge, while post-lunch/dinner Metformin controls postprandial glucose excursions.",
                                geriatricSafetyAlerts = listOf(
                                    "Monitor for ankle edema or postural dizziness with Amlodipine.",
                                    "Never double a missed evening Metformin dose to avoid GI distress or lactic acidosis risk."
                                )
                            )
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun MedMateBottomBar(
    currentTab: MedMateTab,
    onSelectTab: (MedMateTab) -> Unit
) {
    NavigationBar(
        containerColor = Color.White
    ) {
        MedMateTab.entries.forEach { tab ->
            val selected = currentTab == tab
            NavigationBarItem(
                selected = selected,
                onClick = { onSelectTab(tab) },
                icon = {
                    val icon = when (tab) {
                        MedMateTab.HOME -> if (selected) Icons.Filled.Home else Icons.Outlined.Home
                        MedMateTab.MEDICINES -> if (selected) Icons.Filled.Medication else Icons.Outlined.Medication
                        MedMateTab.HISTORY -> if (selected) Icons.Filled.History else Icons.Outlined.History
                        MedMateTab.FAMILY -> if (selected) Icons.Filled.Groups else Icons.Outlined.Groups
                        MedMateTab.AI_RX -> if (selected) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome
                    }
                    Icon(imageVector = icon, contentDescription = tab.label)
                },
                label = {
                    Text(
                        text = tab.label,
                        fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFF0A5C52),
                    selectedTextColor = Color(0xFF0A5C52),
                    indicatorColor = MedTealContainer,
                    unselectedIconColor = Color(0xFF5A6D6A),
                    unselectedTextColor = Color(0xFF5A6D6A)
                ),
                modifier = Modifier.testTag("nav_tab_${tab.route}")
            )
        }
    }
}
