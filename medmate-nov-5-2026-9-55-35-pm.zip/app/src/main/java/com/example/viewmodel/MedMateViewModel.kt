package com.example.viewmodel

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BioscienceReport
import com.example.data.model.DoseLog
import com.example.data.model.FamilyMember
import com.example.data.model.Medicine
import com.example.data.model.ScannedPrescriptionMedicine
import com.example.data.model.UserProfile
import com.example.data.repository.MedMateRepository
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.ThinkingLevel
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import com.google.firebase.ai.type.thinkingConfig
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

sealed interface AiTaskState<out T> {
    data object Idle : AiTaskState<Nothing>
    data object Loading : AiTaskState<Nothing>
    data class Success<T>(val data: T) : AiTaskState<T>
    data class Error(val message: String) : AiTaskState<Nothing>
}

class MedMateViewModel(
    private val repository: MedMateRepository,
    private val currentUserId: String,
    private val initialDisplayName: String?
) : ViewModel() {

    // 1. Prescription Scanner Structured JSON Model (gemini-3.8-flash)
    private val prescriptionSchema = Schema.obj(
        properties = mapOf(
            "clinicSummary" to Schema.string(description = "Doctor or clinic summary"),
            "medicines" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "name" to Schema.string(description = "Medicine name and strength e.g. Metformin 500mg"),
                        "dosage" to Schema.string(description = "Dosage e.g. 1 tablet"),
                        "timeSlot" to Schema.enumeration(
                            values = listOf("Morning", "Afternoon", "Evening", "Night"),
                            description = "Time of day slot"
                        ),
                        "scheduledTime" to Schema.string(description = "Clock time e.g. 08:00 AM"),
                        "mealInstruction" to Schema.string(description = "Meal timing e.g. Before Breakfast, After Lunch"),
                        "conditionTag" to Schema.string(description = "Condition e.g. Diabetes, BP, Thyroid, Cholesterol"),
                        "bioscienceMechanism" to Schema.string(description = "Cellular/molecular mechanism of action and food-drug interaction")
                    )
                ),
                description = "Extracted prescription medicines"
            )
        )
    )

    private val prescriptionScannerModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = prescriptionSchema
            }
        )
    }

    // 2. Deep Bioscience & Polypharmacy Reasoning Model (gemini-4-argon)
    private val bioscienceSchema = Schema.obj(
        properties = mapOf(
            "clinicalSummary" to Schema.string(description = "High-level molecular and clinical pharmacology synthesis"),
            "pharmacokineticPathways" to Schema.array(
                items = Schema.string(),
                description = "CYP450, renal/hepatic clearance, and receptor pathways"
            ),
            "drugFoodInteractions" to Schema.array(
                items = Schema.string(),
                description = "Indian diet & meal timing interactions (calcium/iron/tea with thyroxine, etc.)"
            ),
            "chronoPharmacologyTip" to Schema.string(description = "Optimal circadian timing explanation"),
            "geriatricSafetyAlerts" to Schema.array(
                items = Schema.string(),
                description = "Elderly-specific orthostatic, glycemic, or electrolyte monitoring points"
            )
        )
    )

    private val deepBioscienceModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-4-argon",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = bioscienceSchema
                thinkingConfig = thinkingConfig {
                    thinkingLevel = ThinkingLevel.HIGH
                }
            }
        )
    }

    // 3. Fast Regional / Hindi Elderly Explanation Model (gemini-3.5-flash-lite)
    private val fastLiteModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite"
        )
    }

    val userProfileState: StateFlow<UiState<UserProfile?>> = repository.observeUserProfile(currentUserId)
        .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing user profile", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load user profile"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val familyMembersState: StateFlow<UiState<List<FamilyMember>>> = repository.observeFamilyMembers(currentUserId)
        .map<List<FamilyMember>, UiState<List<FamilyMember>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing family members", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to observe family members"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val medicinesState: StateFlow<UiState<List<Medicine>>> = repository.observeMedicines(currentUserId)
        .map<List<Medicine>, UiState<List<Medicine>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing medicines", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to observe medicines"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val doseLogsState: StateFlow<UiState<List<DoseLog>>> = repository.observeDoseLogs(currentUserId)
        .map<List<DoseLog>, UiState<List<DoseLog>>> { list ->
            UiState.Success(list.sortedByDescending { it.createdAt?.seconds ?: 0L })
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing dose logs", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to observe dose logs"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    private val _selectedMemberId = MutableStateFlow<String?>(null)
    val selectedMemberId: StateFlow<String?> = _selectedMemberId.asStateFlow()

    private val _actionFeedback = MutableStateFlow<String?>(null)
    val actionFeedback: StateFlow<String?> = _actionFeedback.asStateFlow()

    private val _scannedMedicinesState = MutableStateFlow<AiTaskState<List<ScannedPrescriptionMedicine>>>(AiTaskState.Idle)
    val scannedMedicinesState: StateFlow<AiTaskState<List<ScannedPrescriptionMedicine>>> = _scannedMedicinesState.asStateFlow()

    private val _bioscienceReportState = MutableStateFlow<AiTaskState<BioscienceReport>>(AiTaskState.Idle)
    val bioscienceReportState: StateFlow<AiTaskState<BioscienceReport>> = _bioscienceReportState.asStateFlow()

    private val _quickHindiExplanationState = MutableStateFlow<AiTaskState<String>>(AiTaskState.Idle)
    val quickHindiExplanationState: StateFlow<AiTaskState<String>> = _quickHindiExplanationState.asStateFlow()

    private val _aiAssistantState = MutableStateFlow<AiTaskState<String>>(AiTaskState.Idle)
    val aiAssistantState: StateFlow<AiTaskState<String>> = _aiAssistantState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedIndianFamilyCareDataIfEmpty(initialDisplayName)
        }
    }

    fun selectFamilyMember(memberId: String?) {
        _selectedMemberId.value = memberId
    }

    fun clearFeedback() {
        _actionFeedback.value = null
    }

    fun markDoseStatus(medicine: Medicine, status: String, notes: String = "") {
        viewModelScope.launch {
            val result = repository.updateMedicineDoseStatus(medicine, status, notes)
            result.onSuccess {
                val label = when (status) {
                    "taken" -> "Confirmed! Marked ${medicine.name} as Taken."
                    "missed" -> "Alert sent to Anita Rao: ${medicine.scheduledTime} dose of ${medicine.name} not confirmed."
                    "snoozed" -> "Snoozed ${medicine.name} for 15 minutes."
                    "skipped" -> "Skipped ${medicine.name} for this slot."
                    else -> "Updated ${medicine.name}"
                }
                _actionFeedback.value = label
            }.onFailure { e ->
                _actionFeedback.value = e.localizedMessage ?: "Failed to update dose status"
            }
        }
    }

    fun addMedicine(
        memberId: String,
        patientName: String,
        name: String,
        dosage: String,
        timeSlot: String,
        scheduledTime: String,
        mealInstruction: String,
        conditionTag: String,
        bioscienceMechanism: String
    ) {
        viewModelScope.launch {
            val res = repository.createMedicine(
                memberId = memberId,
                patientName = patientName,
                name = name,
                dosage = dosage,
                timeSlot = timeSlot,
                scheduledTime = scheduledTime,
                mealInstruction = mealInstruction,
                conditionTag = conditionTag,
                bioscienceMechanism = bioscienceMechanism
            )
            res.onSuccess {
                _actionFeedback.value = "Added $name to $patientName's schedule"
            }.onFailure { e ->
                _actionFeedback.value = e.localizedMessage ?: "Failed to add medicine"
            }
        }
    }

    fun deleteMedicine(medicineId: String) {
        viewModelScope.launch {
            repository.deleteMedicine(medicineId)
        }
    }

    fun addFamilyMember(
        name: String,
        relation: String,
        age: Long,
        bloodGroup: String,
        allergies: String,
        conditions: String,
        city: String,
        phone: String,
        inviteCode: String
    ) {
        viewModelScope.launch {
            val res = repository.createFamilyMember(
                name = name,
                relation = relation,
                age = age,
                bloodGroup = bloodGroup,
                allergies = allergies,
                conditions = conditions,
                city = city,
                phone = phone,
                inviteCode = inviteCode
            )
            res.onSuccess { newId ->
                _selectedMemberId.value = newId
                _actionFeedback.value = "Linked $name ($relation) to your family circle!"
            }.onFailure { e ->
                _actionFeedback.value = e.localizedMessage ?: "Failed to link family member"
            }
        }
    }

    fun updateProfile(
        name: String,
        age: Long,
        bloodGroup: String,
        allergies: String,
        language: String,
        accountMode: String,
        inviteCode: String,
        phone: String
    ) {
        viewModelScope.launch {
            val res = repository.saveUserProfile(
                name = name,
                age = age,
                bloodGroup = bloodGroup,
                allergies = allergies,
                language = language,
                accountMode = accountMode,
                inviteCode = inviteCode,
                phone = phone
            )
            res.onSuccess {
                _actionFeedback.value = "Profile & language preferences saved!"
            }.onFailure { e ->
                _actionFeedback.value = e.localizedMessage ?: "Failed to save profile"
            }
        }
    }

    // AI Feature 1: Scan Prescription (OCR Text or Photo) -> Structured Medicine Schedule
    fun scanPrescriptionWithAi(rawPrescriptionText: String, prescriptionBitmap: Bitmap? = null) {
        viewModelScope.launch {
            _scannedMedicinesState.value = AiTaskState.Loading
            try {
                val prompt = """
                    You are an expert Indian clinical pharmacist and bioscience specialist.
                    Extract all prescribed medicines from this prescription into structured daily schedule data.
                    Understand Indian clinical abbreviations (OD = once daily, BD = twice daily, TDS = thrice daily, HS = at bedtime, BBF = before breakfast, PC = after meals).
                    For each medicine, also provide its concise bioscience mechanism of action (receptor/enzyme target, half-life or meal timing rationale).
                    Prescription input:
                    $rawPrescriptionText
                """.trimIndent()

                val response = withTimeout(60_000L) {
                    if (prescriptionBitmap != null) {
                        prescriptionScannerModel.generateContent(
                            content {
                                image(prescriptionBitmap)
                                text(prompt)
                            }
                        )
                    } else {
                        prescriptionScannerModel.generateContent(prompt)
                    }
                }

                val jsonString = response.text ?: throw IllegalStateException("Model returned empty response.")
                val json = JSONObject(jsonString)
                val medsArray = json.getJSONArray("medicines")
                val parsedList = (0 until medsArray.length()).map { idx ->
                    val item = medsArray.getJSONObject(idx)
                    ScannedPrescriptionMedicine(
                        name = item.optString("name", "Metformin 500mg"),
                        dosage = item.optString("dosage", "1 tablet"),
                        timeSlot = item.optString("timeSlot", "Morning"),
                        scheduledTime = item.optString("scheduledTime", "08:00 AM"),
                        mealInstruction = item.optString("mealInstruction", "After Breakfast"),
                        conditionTag = item.optString("conditionTag", "General"),
                        bioscienceMechanism = item.optString("bioscienceMechanism", "")
                    )
                }
                _scannedMedicinesState.value = AiTaskState.Success(parsedList)
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Prescription scan timed out", e)
                _scannedMedicinesState.value = AiTaskState.Error("Prescription analysis timed out after 60 seconds. Please try again.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Prescription scan failed", e)
                _scannedMedicinesState.value = AiTaskState.Error(e.localizedMessage ?: "Prescription analysis failed.")
            }
        }
    }

    // AI Feature 2: Deep Bioscience & Polypharmacy Interaction Analysis (gemini-4-argon)
    fun runDeepBioscienceAnalysis(medicines: List<Medicine>, patient: FamilyMember?) {
        viewModelScope.launch {
            _bioscienceReportState.value = AiTaskState.Loading
            try {
                val medsDescription = medicines.joinToString("\n") {
                    "- ${it.name} (${it.dosage}, ${it.timeSlot} - ${it.mealInstruction}, Condition: ${it.conditionTag})"
                }
                val prompt = """
                    Perform a rigorous Bioscience & Clinical Pharmacology polypharmacy analysis for an elderly Indian patient:
                    Patient: ${patient?.name ?: "Kamla ji"}, Age: ${patient?.age ?: 67}, Blood Group: ${patient?.bloodGroup ?: "B+"},
                    Conditions: ${patient?.conditions ?: "Type 2 Diabetes, Hypertension, Hypothyroidism"},
                    Allergies: ${patient?.allergies ?: "None"}.
                    Current Regimen:
                    $medsDescription

                    Analyze:
                    1. Molecular mechanisms, enzyme/receptor targets (AMPK, AT1R, HMG-CoA reductase, T4->T3 deiodination, L-type Ca2+ channels), and hepatic CYP450 / renal clearance pathways.
                    2. Drug-food & Indian meal timing interactions (e.g., Levothyroxine absorption chelation with morning chai/milk/calcium/iron, statin nocturnal cholesterol synthesis).
                    3. Chronopharmacology optimization and geriatric safety monitoring (orthostatic hypotension, hypoglycemia, serum potassium/creatinine).
                """.trimIndent()

                val response = withTimeout(60_000L) {
                    deepBioscienceModel.generateContent(prompt)
                }
                val jsonString = response.text ?: throw IllegalStateException("Empty bioscience response.")
                val json = JSONObject(jsonString)

                val pathwaysArr = json.optJSONArray("pharmacokineticPathways")
                val pathways = if (pathwaysArr != null) {
                    (0 until pathwaysArr.length()).map { pathwaysArr.getString(it) }
                } else emptyList()

                val foodArr = json.optJSONArray("drugFoodInteractions")
                val foodInteractions = if (foodArr != null) {
                    (0 until foodArr.length()).map { foodArr.getString(it) }
                } else emptyList()

                val alertsArr = json.optJSONArray("geriatricSafetyAlerts")
                val alerts = if (alertsArr != null) {
                    (0 until alertsArr.length()).map { alertsArr.getString(it) }
                } else emptyList()

                _bioscienceReportState.value = AiTaskState.Success(
                    BioscienceReport(
                        clinicalSummary = json.optString("clinicalSummary", ""),
                        pharmacokineticPathways = pathways,
                        drugFoodInteractions = foodInteractions,
                        chronoPharmacologyTip = json.optString("chronoPharmacologyTip", ""),
                        geriatricSafetyAlerts = alerts
                    )
                )
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Bioscience analysis timed out", e)
                _bioscienceReportState.value = AiTaskState.Error("Bioscience analysis timed out after 60 seconds.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Bioscience analysis failed", e)
                _bioscienceReportState.value = AiTaskState.Error(e.localizedMessage ?: "Bioscience analysis failed.")
            }
        }
    }

    // AI Feature 3: Fast Bilingual (Hindi + English) Elderly-Friendly Dose Guide (gemini-3.5-flash-lite)
    fun generateQuickElderlyGuide(medicine: Medicine) {
        viewModelScope.launch {
            _quickHindiExplanationState.value = AiTaskState.Loading
            try {
                val prompt = """
                    Explain this medicine to an elderly Indian parent (${medicine.patientName}) in warm, respectful Hinglish (simple Hindi in Roman script + English, starting with "Namaste ${medicine.patientName}!").
                    Medicine: ${medicine.name} (${medicine.dosage}), Time: ${medicine.scheduledTime} (${medicine.mealInstruction}), For: ${medicine.conditionTag}.
                    Keep it to 3 short, reassuring sentences explaining why it helps and how to take it safely with water.
                """.trimIndent()

                val response = withTimeout(45_000L) {
                    fastLiteModel.generateContent(prompt)
                }
                val text = response.text
                if (!text.isNullOrBlank()) {
                    _quickHindiExplanationState.value = AiTaskState.Success(text)
                } else {
                    _quickHindiExplanationState.value = AiTaskState.Error("Empty response from model.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Quick guide timed out", e)
                _quickHindiExplanationState.value = AiTaskState.Error("Request timed out.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Quick guide failed", e)
                _quickHindiExplanationState.value = AiTaskState.Error(e.localizedMessage ?: "Failed to generate guide.")
            }
        }
    }

    fun dismissQuickGuide() {
        _quickHindiExplanationState.value = AiTaskState.Idle
    }

    // AI Feature 4: Multilingual MediMate AI Health Assistant (English, Hindi, Telugu) with strict clinical safety rules
    fun askMediMateAiAssistant(question: String, language: String, medicines: List<Medicine>) {
        viewModelScope.launch {
            _aiAssistantState.value = AiTaskState.Loading
            try {
                val medsList = medicines.joinToString("\n") {
                    "- ${it.name} (${it.dosage}) scheduled at ${it.scheduledTime} (${it.mealInstruction}), status today: ${it.todayStatus}"
                }
                val prompt = """
                    You are the MediMate AI Health Assistant ("Never Miss a Medicine. Never Feel Alone.") for elderly Indian patients and their family caregivers.
                    Respond in $language (if Hindi, include Devanagari script plus simple Roman transliteration; if Telugu, include Telugu script plus simple English explanation; if English, use warm, clear senior-friendly English).

                    STRICT MEDICAL SAFETY RULES:
                    1. NEVER diagnose any medical condition.
                    2. NEVER prescribe new medicines.
                    3. NEVER recommend changing a dosage or doubling a missed dose.
                    4. If asked about an unconfirmed/missed dose, advise checking with the patient first and consulting the prescribing doctor before taking a late dose.
                    5. End with a short medical disclaimer reminding the user to follow their doctor's advice.

                    Current Prescribed Schedule:
                    $medsList

                    User Question:
                    $question
                """.trimIndent()

                val response = withTimeout(45_000L) {
                    fastLiteModel.generateContent(prompt)
                }
                val text = response.text
                if (!text.isNullOrBlank()) {
                    _aiAssistantState.value = AiTaskState.Success(text)
                } else {
                    _aiAssistantState.value = AiTaskState.Error("Empty response from MediMate AI.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI Assistant timed out", e)
                _aiAssistantState.value = AiTaskState.Error("MediMate AI request timed out.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI Assistant failed", e)
                _aiAssistantState.value = AiTaskState.Error(e.localizedMessage ?: "Failed to reach MediMate AI.")
            }
        }
    }

    companion object {
        private const val TAG = "MedMateVM"
        private const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
