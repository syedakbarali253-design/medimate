package com.example.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.R
import java.util.Locale

object ReminderNotificationHelper {
    private const val CHANNEL_ID = "medimate_dose_reminders"
    private const val CHANNEL_NAME = "MediMate Dose & Caregiver Alerts"

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    fun initTtsIfNeeded(context: Context) {
        if (tts != null) return
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                isTtsReady = (status == TextToSpeech.SUCCESS)
            }
        } catch (_: Exception) {
        }
    }

    fun speakMedicineReminder(
        context: Context,
        language: String,
        medicineName: String = "prescribed medicine",
        customMessage: String? = null
    ) {
        initTtsIfNeeded(context)
        val locale = when {
            language.contains("Hindi", ignoreCase = true) || language.contains("हिंदी") -> Locale("hi", "IN")
            language.contains("Telugu", ignoreCase = true) || language.contains("తెలుగు") -> Locale("te", "IN")
            else -> Locale.ENGLISH
        }

        val textToSpeak = customMessage ?: when {
            language.contains("Hindi", ignoreCase = true) || language.contains("हिंदी") ->
                "नमस्ते श्री राव जी! आपकी निर्धारित दवा $medicineName लेने का समय हो गया है। कृपया अपना पर्चा देखें और दवा लेने के बाद पुष्टि करें।"
            language.contains("Telugu", ignoreCase = true) || language.contains("తెలుగు") ->
                "నమస్కారం రావు గారు! మీ $medicineName మందు వేసుకునే సమయం అయింది. దయచేసి మీ ప్రిస్క్రిప్షన్ చూసి, మందు వేసుకున్న తర్వాత నిర్ధారించండి."
            else ->
                "Hello! It is time for your scheduled medicine, $medicineName. Please check your prescription and confirm when you have taken it."
        }

        try {
            val engine = tts
            if (engine != null && isTtsReady) {
                engine.language = locale
                engine.setSpeechRate(0.92f)
                engine.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, "medimate_tts_id")
            }
        } catch (_: Exception) {
        }
    }

    /**
     * Plays a clear, senior-friendly medical alarm pattern using Android ToneGenerator
     * with Ringtone fallback so elderly patients hear scheduled/missed dose alerts immediately.
     */
    fun playAlarmSound(context: Context, isConfirmationChime: Boolean = false) {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_ALARM, 95)
            val handler = Handler(Looper.getMainLooper())
            if (isConfirmationChime) {
                toneGen.startTone(ToneGenerator.TONE_PROP_ACK, 260)
                handler.postDelayed({ toneGen.release() }, 350L)
            } else {
                // Distinct 3-pulse medical reminder alarm
                toneGen.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 400)
                handler.postDelayed({
                    try {
                        toneGen.startTone(ToneGenerator.TONE_CDMA_MED_SLS, 450)
                    } catch (_: Exception) {
                    }
                }, 480L)
                handler.postDelayed({
                    try {
                        toneGen.release()
                    } catch (_: Exception) {
                    }
                }, 1100L)
            }
        } catch (_: Exception) {
            try {
                val uri = RingtoneManager.getDefaultUri(
                    if (isConfirmationChime) RingtoneManager.TYPE_NOTIFICATION else RingtoneManager.TYPE_ALARM
                )
                val ringtone = RingtoneManager.getRingtone(context.applicationContext, uri)
                ringtone?.play()
            } catch (_: Exception) {
            }
        }
    }

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Scheduled medicine reminders and caregiver unconfirmed-dose alerts"
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun sendDoseReminderNotification(
        context: Context,
        title: String,
        body: String,
        playAlarm: Boolean = true,
        notificationId: Int = (System.currentTimeMillis() % 10000).toInt()
    ): Boolean {
        if (playAlarm) {
            playAlarmSound(context, isConfirmationChime = false)
        }
        ensureChannel(context)
        if (!hasNotificationPermission(context)) return false
        return try {
            val launchIntent = android.content.Intent(context, com.example.MainActivity::class.java).apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = android.app.PendingIntent.getActivity(
                context,
                notificationId,
                launchIntent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.medmate_logo_fg)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(context).notify(notificationId, notification)
            true
        } catch (e: SecurityException) {
            false
        }
    }
}
