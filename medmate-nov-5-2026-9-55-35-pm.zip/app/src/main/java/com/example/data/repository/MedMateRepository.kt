package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.DoseLog
import com.example.data.model.FamilyMember
import com.example.data.model.Medicine
import com.example.data.model.UserProfile
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class MedMateRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeUserProfile(userId: String = requireUserId()): Flow<UserProfile?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    } else {
                        null
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observeFamilyMembers(userId: String = requireUserId()): Flow<List<FamilyMember>> = flow {
        val path = "family_members"
        emitAll(
            db.collection("family_members")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(FamilyMember::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMedicines(userId: String = requireUserId()): Flow<List<Medicine>> = flow {
        val path = "medicines"
        emitAll(
            db.collection("medicines")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(Medicine::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeDoseLogs(userId: String = requireUserId()): Flow<List<DoseLog>> = flow {
        val path = "dose_logs"
        emitAll(
            db.collection("dose_logs")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(DoseLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveUserProfile(
        name: String,
        age: Long,
        bloodGroup: String,
        allergies: String,
        language: String,
        accountMode: String,
        inviteCode: String,
        phone: String
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val existingSnap = try {
            docRef.get().await()
        } catch (e: Exception) {
            null
        }

        if (existingSnap != null && existingSnap.exists()) {
            val updatePayload = mapOf(
                "name" to name.take(100),
                "age" to age.coerceIn(0L, 130L),
                "bloodGroup" to bloodGroup.ifBlank { "O+" }.take(20),
                "allergies" to allergies.take(300),
                "language" to language.ifBlank { "English / Hindi" }.take(40),
                "accountMode" to if (accountMode in listOf("patient", "caregiver", "both")) accountMode else "both",
                "inviteCode" to inviteCode.ifBlank { "MM-4829" }.take(20),
                "phone" to phone.take(30),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updatePayload).await()
        } else {
            val createPayload = mapOf(
                "userId" to uid,
                "name" to name.ifBlank { "Rahul Sharma" }.take(100),
                "age" to age.coerceIn(0L, 130L),
                "bloodGroup" to bloodGroup.ifBlank { "O+" }.take(20),
                "allergies" to allergies.take(300),
                "language" to language.ifBlank { "English / Hindi" }.take(40),
                "accountMode" to if (accountMode in listOf("patient", "caregiver", "both")) accountMode else "both",
                "inviteCode" to inviteCode.ifBlank { "MM-4829" }.take(20),
                "phone" to phone.take(30),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(createPayload).await()
        }
        uid
    }.onFailure { e ->
        if (e is CancellationException) throw e
        val uid = auth.currentUser?.uid ?: "unknown"
        handleFirestoreError(e, OperationType.WRITE, "users/$uid")
    }

    suspend fun createFamilyMember(
        name: String,
        relation: String,
        age: Long,
        bloodGroup: String,
        allergies: String,
        conditions: String,
        city: String,
        phone: String,
        inviteCode: String,
        adherenceTakenToday: Long = 0L,
        adherenceTotalToday: Long = 0L,
        missedDosesToday: Long = 0L,
        lastMissedMedicine: String = "",
        weeklyAdherencePct: Long = 90L
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val memberId = "fam_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        val docRef = db.collection("family_members").document(memberId)
        val payload = mapOf(
            "userId" to uid,
            "name" to name.trim().ifBlank { "Kamla ji" }.take(100),
            "relation" to relation.trim().ifBlank { "Mother" }.take(50),
            "age" to age.coerceIn(1L, 130L),
            "bloodGroup" to bloodGroup.trim().ifBlank { "B+" }.take(20),
            "allergies" to allergies.trim().take(300),
            "conditions" to conditions.trim().take(300),
            "city" to city.trim().take(100),
            "phone" to phone.trim().take(30),
            "inviteCode" to inviteCode.trim().ifBlank { "MM-1001" }.take(30),
            "adherenceTakenToday" to adherenceTakenToday.coerceIn(0L, 100L),
            "adherenceTotalToday" to adherenceTotalToday.coerceIn(0L, 100L),
            "missedDosesToday" to missedDosesToday.coerceIn(0L, 100L),
            "lastMissedMedicine" to lastMissedMedicine.take(200),
            "weeklyAdherencePct" to weeklyAdherencePct.coerceIn(0L, 100L),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        docRef.set(payload).await()
        memberId
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, "family_members")
    }

    suspend fun createMedicine(
        memberId: String,
        patientName: String,
        name: String,
        dosage: String,
        timeSlot: String,
        scheduledTime: String,
        mealInstruction: String,
        conditionTag: String,
        bioscienceMechanism: String,
        stockRemaining: Long = 30L,
        takenToday: Boolean = false,
        todayStatus: String = "pending"
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val medId = "med_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        val docRef = db.collection("medicines").document(medId)
        val validSlot = if (timeSlot in listOf("Morning", "Afternoon", "Evening", "Night")) timeSlot else "Morning"
        val validStatus = if (todayStatus in listOf("pending", "taken", "skipped", "snoozed", "missed")) todayStatus else "pending"
        val payload = mapOf(
            "userId" to uid,
            "memberId" to memberId.ifBlank { "default_member" }.take(128),
            "patientName" to patientName.ifBlank { "Kamla ji" }.take(100),
            "name" to name.trim().ifBlank { "Metformin 500mg" }.take(120),
            "dosage" to dosage.trim().ifBlank { "1 tablet" }.take(80),
            "timeSlot" to validSlot,
            "scheduledTime" to scheduledTime.trim().ifBlank { "08:00 AM" }.take(30),
            "mealInstruction" to mealInstruction.trim().ifBlank { "After Breakfast" }.take(80),
            "conditionTag" to conditionTag.trim().ifBlank { "General" }.take(60),
            "bioscienceMechanism" to bioscienceMechanism.trim().take(600),
            "stockRemaining" to stockRemaining.coerceIn(0L, 10000L),
            "takenToday" to takenToday,
            "todayStatus" to validStatus,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        docRef.set(payload).await()
        medId
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, "medicines")
    }

    suspend fun getUserMedicines(): Result<List<Medicine>> = runCatching {
        val uid = requireUserId()
        val snap = db.collection("medicines")
            .whereEqualTo("userId", uid)
            .get()
            .await()
        snap.toObjects(Medicine::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.LIST, "medicines")
    }

    suspend fun getMedicineById(medicineId: String): Result<Medicine?> = runCatching {
        val snap = db.collection("medicines")
            .document(medicineId)
            .get()
            .await()
        snap.toObject(Medicine::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.GET, "medicines/$medicineId")
    }

    suspend fun updateMedicineDoseStatus(
        medicine: Medicine,
        newStatus: String,
        notes: String = ""
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(medicine.id.isNotBlank()) { "Medicine ID must not be blank" }
        val medRef = db.collection("medicines").document(medicine.id)
        val validStatus = if (newStatus in listOf("pending", "taken", "skipped", "snoozed", "missed")) newStatus else "taken"
        val isTaken = validStatus == "taken"
        val updatedStock = if (isTaken && !medicine.takenToday && medicine.stockRemaining > 0) {
            medicine.stockRemaining - 1L
        } else {
            medicine.stockRemaining
        }

        medRef.update(
            mapOf(
                "takenToday" to isTaken,
                "todayStatus" to validStatus,
                "stockRemaining" to updatedStock,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        if (validStatus in listOf("taken", "skipped", "snoozed", "missed")) {
            val logId = "log_${UUID.randomUUID().toString().replace("-", "").take(12)}"
            val logRef = db.collection("dose_logs").document(logId)
            logRef.set(
                mapOf(
                    "userId" to uid,
                    "memberId" to medicine.memberId.ifBlank { "default_member" }.take(128),
                    "patientName" to medicine.patientName.ifBlank { "Kamla ji" }.take(100),
                    "medicineId" to medicine.id.take(128),
                    "medicineName" to medicine.name.take(120),
                    "dosage" to medicine.dosage.take(80),
                    "scheduledTime" to medicine.scheduledTime.take(30),
                    "actionStatus" to validStatus,
                    "notes" to notes.take(300),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "medicines/${medicine.id}")
    }

    suspend fun deleteMedicine(medicineId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection("medicines").document(medicineId)
        docRef.delete().await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.DELETE, "medicines/$medicineId")
    }

    suspend fun seedIndianFamilyCareDataIfEmpty(displayName: String?): Result<Unit> = runCatching {
        val uid = requireUserId()
        val existingMeds = db.collection("medicines")
            .whereEqualTo("userId", uid)
            .limit(1)
            .get()
            .await()
        if (!existingMeds.isEmpty) return@runCatching

        val userDoc = db.collection("users").document(uid).get().await()
        if (!userDoc.exists()) {
            saveUserProfile(
                name = displayName?.takeIf { it.isNotBlank() } ?: "Anita Rao & Mr. Rao",
                age = 72L,
                bloodGroup = "O+",
                allergies = "Sulfa drugs",
                language = "English",
                accountMode = "both",
                inviteCode = "MM-${uid.take(4).uppercase()}",
                phone = "+91 98480 22334"
            ).getOrThrow()
        }

        // Seed Mr. Rao (connected to Daughter Anita Rao, matching MediMate_Elder_Care_App_Dashboard)
        val mrRaoId = createFamilyMember(
            name = "Mr. Rao",
            relation = "Father (Connected: Anita Rao)",
            age = 72L,
            bloodGroup = "O+",
            allergies = "None",
            conditions = "Hypertension, Type 2 Diabetes, Vitamin D Deficiency",
            city = "Hyderabad, TG",
            phone = "+91 98480 11223",
            inviteCode = "MM-RAO1",
            adherenceTakenToday = 2L,
            adherenceTotalToday = 3L,
            missedDosesToday = 1L,
            lastMissedMedicine = "8:00 PM dose not confirmed",
            weeklyAdherencePct = 92L
        ).getOrThrow()

        val kamlaId = createFamilyMember(
            name = "Kamla ji (Mummy)",
            relation = "Mother",
            age = 68L,
            bloodGroup = "B+",
            allergies = "Sulfa drugs",
            conditions = "Type 2 Diabetes, Hypothyroidism",
            city = "Jaipur, RJ",
            phone = "+91 98290 55110",
            inviteCode = "MM-KMLA",
            adherenceTakenToday = 3L,
            adherenceTotalToday = 3L,
            missedDosesToday = 0L,
            lastMissedMedicine = "",
            weeklyAdherencePct = 96L
        ).getOrThrow()

        // Mr. Rao's 4 medicines matching the uploaded MediMate Elder Care App Dashboard
        val med1Id = createMedicine(
            memberId = mrRaoId,
            patientName = "Mr. Rao",
            name = "Amlodipine 5 mg",
            dosage = "1 tablet • Once daily",
            timeSlot = "Morning",
            scheduledTime = "8:00 AM",
            mealInstruction = "After Breakfast • Dr. Reddy",
            conditionTag = "BP",
            bioscienceMechanism = "Dihydropyridine L-type calcium channel blocker; relaxes arterial smooth muscle for 24h blood pressure control.",
            stockRemaining = 26L,
            takenToday = true,
            todayStatus = "taken"
        ).getOrThrow()

        createMedicine(
            memberId = mrRaoId,
            patientName = "Mr. Rao",
            name = "Metformin 500 mg",
            dosage = "1 tablet • Twice daily",
            timeSlot = "Afternoon",
            scheduledTime = "1:00 PM",
            mealInstruction = "1:00 PM & 8:00 PM • After Meals",
            conditionTag = "Diabetes",
            bioscienceMechanism = "Biguanide AMPK activator: suppresses hepatic gluconeogenesis and enhances peripheral GLUT4 glucose uptake.",
            stockRemaining = 22L,
            takenToday = false,
            todayStatus = "pending"
        ).getOrThrow()

        val med3Id = createMedicine(
            memberId = mrRaoId,
            patientName = "Mr. Rao",
            name = "Vitamin D",
            dosage = "1 tablet • Daily",
            timeSlot = "Night",
            scheduledTime = "8:00 PM",
            mealInstruction = "After Dinner • Dr. Reddy",
            conditionTag = "Supplement",
            bioscienceMechanism = "Cholecalciferol (Vitamin D3) regulates intestinal calcium absorption and parathyroid hormone balance.",
            stockRemaining = 18L,
            takenToday = false,
            todayStatus = "pending"
        ).getOrThrow()

        createMedicine(
            memberId = mrRaoId,
            patientName = "Mr. Rao",
            name = "Calcium 600 mg",
            dosage = "1 tablet • Daily",
            timeSlot = "Night",
            scheduledTime = "9:00 PM",
            mealInstruction = "After Dinner • Dr. Reddy",
            conditionTag = "Supplement",
            bioscienceMechanism = "Supports bone mineral density and neuromuscular signaling in elderly patients.",
            stockRemaining = 20L,
            takenToday = false,
            todayStatus = "missed"
        ).getOrThrow()

        // Kamla ji's medicine
        createMedicine(
            memberId = kamlaId,
            patientName = "Kamla ji (Mummy)",
            name = "Thyroxine 50 mcg",
            dosage = "1 tablet • Once daily",
            timeSlot = "Morning",
            scheduledTime = "7:00 AM",
            mealInstruction = "Before Breakfast (Empty Stomach)",
            conditionTag = "Thyroid",
            bioscienceMechanism = "Synthetic T4 prohormone converted peripherally to active T3 via deiodinases.",
            stockRemaining = 30L,
            takenToday = true,
            todayStatus = "taken"
        ).getOrThrow()

        // Seed initial DoseLogs matching Screen 3 ("8:00 AM - Medicine confirmed", "1:00 PM - Medicine confirmed", "8:30 PM - Alert sent")
        val logRef1 = db.collection("dose_logs").document("log_${UUID.randomUUID().toString().replace("-", "").take(10)}")
        logRef1.set(
            mapOf(
                "userId" to uid,
                "memberId" to mrRaoId,
                "patientName" to "Mr. Rao",
                "medicineId" to med1Id,
                "medicineName" to "Amlodipine 5 mg",
                "dosage" to "1 tablet",
                "scheduledTime" to "8:00 AM",
                "actionStatus" to "taken",
                "notes" to "8:00 AM – Medicine confirmed",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        val logRef2 = db.collection("dose_logs").document("log_${UUID.randomUUID().toString().replace("-", "").take(10)}")
        logRef2.set(
            mapOf(
                "userId" to uid,
                "memberId" to mrRaoId,
                "patientName" to "Mr. Rao",
                "medicineId" to med3Id,
                "medicineName" to "8:00 PM Scheduled Dose",
                "dosage" to "1 tablet",
                "scheduledTime" to "8:30 PM",
                "actionStatus" to "missed",
                "notes" to "8:30 PM – Alert sent (30m grace period elapsed)",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        Unit
    }
}
