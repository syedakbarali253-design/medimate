package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "Anita Rao",
    val age: Long = 42L,
    val bloodGroup: String = "O+",
    val allergies: String = "None",
    val language: String = "English", // "English", "Hindi", "Telugu"
    val accountMode: String = "both", // "patient", "caregiver", "both"
    val inviteCode: String = "MM-RAO1",
    val phone: String = "+91 98480 22334",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FamilyMember(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val relation: String = "Father",
    val age: Long = 72L,
    val bloodGroup: String = "O+",
    val allergies: String = "None",
    val conditions: String = "Hypertension, Type 2 Diabetes, Vitamin D Deficiency",
    val city: String = "Hyderabad, TG",
    val phone: String = "+91 98480 11223",
    val inviteCode: String = "MM-RAO1",
    val adherenceTakenToday: Long = 2L,
    val adherenceTotalToday: Long = 3L,
    val missedDosesToday: Long = 1L,
    val lastMissedMedicine: String = "8:00 PM dose not confirmed",
    val weeklyAdherencePct: Long = 90L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Medicine(
    @DocumentId val id: String = "",
    val userId: String = "",
    val memberId: String = "",
    val patientName: String = "",
    val name: String = "",
    val dosage: String = "1 tablet",
    val timeSlot: String = "Morning", // "Morning", "Afternoon", "Evening", "Night"
    val scheduledTime: String = "8:00 AM",
    val mealInstruction: String = "Once daily • After Breakfast",
    val conditionTag: String = "BP",
    val bioscienceMechanism: String = "",
    val stockRemaining: Long = 30L,
    val takenToday: Boolean = false,
    val todayStatus: String = "pending", // "pending", "taken", "skipped", "snoozed", "missed"
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class DoseLog(
    @DocumentId val id: String = "",
    val userId: String = "",
    val memberId: String = "",
    val patientName: String = "",
    val medicineId: String = "",
    val medicineName: String = "",
    val dosage: String = "",
    val scheduledTime: String = "",
    val actionStatus: String = "taken", // "taken", "skipped", "snoozed", "missed"
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class ScannedPrescriptionMedicine(
    val name: String,
    val dosage: String,
    val timeSlot: String,
    val scheduledTime: String,
    val mealInstruction: String,
    val conditionTag: String,
    val bioscienceMechanism: String
)

data class BioscienceReport(
    val clinicalSummary: String,
    val pharmacokineticPathways: List<String>,
    val drugFoodInteractions: List<String>,
    val chronoPharmacologyTip: String,
    val geriatricSafetyAlerts: List<String>
)

object MedMateDemoData {
    fun defaultProfile(role: String): UserProfile = UserProfile(
        id = "demo_user",
        userId = "demo_user",
        name = if (role == "caregiver") "Anita Rao (Daughter)" else "Mr. Rao",
        age = if (role == "caregiver") 42L else 72L,
        bloodGroup = "O+",
        allergies = "Sulfa drugs",
        language = "English",
        accountMode = role,
        inviteCode = "MM-RAO1",
        phone = "+91 98480 22334"
    )

    fun defaultFamilyMembers(): List<FamilyMember> = listOf(
        FamilyMember(
            id = "demo_mr_rao",
            userId = "demo_user",
            name = "Mr. Rao",
            relation = "Father (Connected to Anita Rao)",
            age = 72L,
            bloodGroup = "O+",
            allergies = "None",
            conditions = "Hypertension, Type 2 Diabetes, Osteopenia",
            city = "Hyderabad, TG",
            phone = "+91 98480 11223",
            inviteCode = "MM-RAO1",
            adherenceTakenToday = 2L,
            adherenceTotalToday = 3L,
            missedDosesToday = 1L,
            lastMissedMedicine = "8:00 PM dose not confirmed",
            weeklyAdherencePct = 92L
        ),
        FamilyMember(
            id = "demo_kamla_ji",
            userId = "demo_user",
            name = "Kamla ji (Mummy)",
            relation = "Mother",
            age = 68L,
            bloodGroup = "B+",
            allergies = "Sulfa drugs",
            conditions = "Type 2 Diabetes, Hypothyroidism",
            city = "Jaipur, RJ",
            phone = "+91 98290 55110",
            inviteCode = "MM-KMLA",
            adherenceTakenToday = 3L,
            adherenceTotalToday = 3L,
            missedDosesToday = 0L,
            lastMissedMedicine = "",
            weeklyAdherencePct = 96L
        )
    )

    fun defaultMedicines(): List<Medicine> = listOf(
        Medicine(
            id = "demo_med_1",
            userId = "demo_user",
            memberId = "demo_mr_rao",
            patientName = "Mr. Rao",
            name = "Amlodipine 5 mg",
            dosage = "1 tablet • Once daily",
            timeSlot = "Morning",
            scheduledTime = "8:00 AM",
            mealInstruction = "After Breakfast • Dr. Reddy",
            conditionTag = "BP",
            bioscienceMechanism = "Dihydropyridine L-type calcium channel blocker; smoothly reduces arterial blood pressure over 24 hours.",
            stockRemaining = 26L,
            takenToday = true,
            todayStatus = "taken"
        ),
        Medicine(
            id = "demo_med_2",
            userId = "demo_user",
            memberId = "demo_mr_rao",
            patientName = "Mr. Rao",
            name = "Metformin 500 mg",
            dosage = "1 tablet • Twice daily",
            timeSlot = "Afternoon",
            scheduledTime = "1:00 PM",
            mealInstruction = "After Lunch (1:00 PM & 8:00 PM) • Dr. Reddy",
            conditionTag = "Diabetes",
            bioscienceMechanism = "Hepatic AMPK activator; reduces gluconeogenesis and improves peripheral insulin sensitivity.",
            stockRemaining = 22L,
            takenToday = false,
            todayStatus = "pending"
        ),
        Medicine(
            id = "demo_med_3",
            userId = "demo_user",
            memberId = "demo_mr_rao",
            patientName = "Mr. Rao",
            name = "Vitamin D",
            dosage = "1 tablet • Daily",
            timeSlot = "Night",
            scheduledTime = "8:00 PM",
            mealInstruction = "After Dinner • Dr. Reddy",
            conditionTag = "Supplement",
            bioscienceMechanism = "Cholecalciferol (Vitamin D3) enhances intestinal calcium and phosphate absorption for geriatric bone density.",
            stockRemaining = 18L,
            takenToday = false,
            todayStatus = "pending"
        ),
        Medicine(
            id = "demo_med_4",
            userId = "demo_user",
            memberId = "demo_mr_rao",
            patientName = "Mr. Rao",
            name = "Calcium 600 mg",
            dosage = "1 tablet • Daily",
            timeSlot = "Night",
            scheduledTime = "9:00 PM",
            mealInstruction = "After Dinner • Dr. Reddy",
            conditionTag = "Supplement",
            bioscienceMechanism = "Elemental calcium supplement supporting myocardial contractility and skeletal mineralization.",
            stockRemaining = 20L,
            takenToday = false,
            todayStatus = "missed"
        )
    )

    fun defaultDoseLogs(): List<DoseLog> = listOf(
        DoseLog(
            id = "demo_log_1",
            userId = "demo_user",
            memberId = "demo_mr_rao",
            patientName = "Mr. Rao",
            medicineId = "demo_med_1",
            medicineName = "Amlodipine 5 mg",
            dosage = "1 tablet",
            scheduledTime = "8:00 AM",
            actionStatus = "taken",
            notes = "8:00 AM – Medicine confirmed"
        ),
        DoseLog(
            id = "demo_log_2",
            userId = "demo_user",
            memberId = "demo_mr_rao",
            patientName = "Mr. Rao",
            medicineId = "demo_med_2",
            medicineName = "Metformin 500 mg",
            dosage = "1 tablet",
            scheduledTime = "1:00 PM",
            actionStatus = "taken",
            notes = "1:00 PM – Medicine confirmed"
        ),
        DoseLog(
            id = "demo_log_3",
            userId = "demo_user",
            memberId = "demo_mr_rao",
            patientName = "Mr. Rao",
            medicineId = "demo_med_3",
            medicineName = "8:00 PM Prescribed Dose",
            dosage = "1 tablet",
            scheduledTime = "8:30 PM",
            actionStatus = "missed",
            notes = "8:30 PM – Caregiver alert sent (30m grace period elapsed)"
        )
    )
}
